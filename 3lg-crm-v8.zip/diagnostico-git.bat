@echo off
REM ============================================================
REM  Diagnostico Git - 3LG Turismo CRM
REM  Coloque este arquivo na RAIZ do projeto e clique 2x nele,
REM  ou rode "diagnostico-git.bat" no terminal dentro da pasta.
REM  So le a situacao - NAO altera nada no seu repositorio.
REM ============================================================
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ============================================================
echo   DIAGNOSTICO GIT - 3LG TURISMO CRM
echo ============================================================
echo   Pasta atual: %cd%
echo.

REM --- 1. Git esta instalado? ---
where git >nul 2>nul
if errorlevel 1 (
  echo [X] Git NAO encontrado nesta maquina.
  echo     Instale em https://git-scm.com/download/win e rode de novo.
  goto fim
)
echo [OK] Git instalado.
for /f "delims=" %%v in ('git --version') do echo      %%v
echo.

REM --- 2. A pasta e um repositorio Git? ---
if not exist ".git" (
  echo [X] Esta pasta NAO e um repositorio Git ^(nao existe .git^).
  echo     Se for a primeira vez, rode:
  echo         git init
  echo         git add .
  echo         git commit -m "Primeiro commit"
  echo     Depois siga o Passo 3 do GUIA-GIT-3LG.md ^(criar repo no GitHub^).
  goto fim
)
echo [OK] Repositorio Git encontrado.
echo.

REM --- 3. Branch atual ---
for /f "delims=" %%b in ('git rev-parse --abbrev-ref HEAD 2^>nul') do set BRANCH=%%b
echo [i] Branch atual: !BRANCH!
echo.

REM --- 4. Remote configurado ---
echo ------------------------------------------------------------
echo   REMOTE ^(para onde o Git envia^):
echo ------------------------------------------------------------
git remote -v
git remote -v | findstr /r "." >nul
if errorlevel 1 (
  echo.
  echo [X] Nenhum remote configurado - por isso o push falha.
  echo     Causa provavel do 404: o repositorio ainda nao foi ligado ao GitHub.
  echo     Siga o Passo 3 do GUIA-GIT-3LG.md.
) else (
  echo.
  echo [i] Confira acima se o usuario e o nome do repo estao corretos.
  echo     Se o endereco estiver certo e ainda der 404, o repo pode nao existir
  echo     no GitHub ou seu token venceu ^(Passos 4 e 5 do guia^).
)
echo.

REM --- 5. Protecao dos segredos ---
echo ------------------------------------------------------------
echo   SEGURANCA DOS SEGREDOS ^(regra 2 do projeto^):
echo ------------------------------------------------------------
if exist ".gitignore" (
  echo [OK] .gitignore existe.
) else (
  echo [X] .gitignore NAO existe - copie o que foi gerado para esta pasta.
)

if exist ".env" (
  echo [i] Arquivo .env encontrado. Verificando se esta protegido...
  git ls-files --error-unmatch .env >nul 2>nul
  if errorlevel 1 (
    echo [OK] .env NAO esta sendo versionado. Seguro.
  ) else (
    echo [X] ALERTA: o .env ESTA sendo rastreado pelo Git!
    echo     Remova-o do versionamento sem apagar do disco:
    echo         git rm --cached .env
    echo         git commit -m "Remove .env do versionamento"
  )
) else (
  echo [i] Nenhum .env nesta pasta ^(ok - talvez ainda nao criado^).
)
echo.

REM --- 6. Arquivos sensiveis que possam ter escapado ---
echo ------------------------------------------------------------
echo   Procurando arquivos sensiveis rastreados por engano...
echo ------------------------------------------------------------
set ACHOU=0
for %%p in (".env" "*.key" "*.pem" "service-account*.json" "credentials*.json") do (
  git ls-files %%p 2>nul | findstr /r "." >nul && (
    echo [X] Rastreado por engano: %%p
    set ACHOU=1
  )
)
if "!ACHOU!"=="0" echo [OK] Nenhum arquivo sensivel rastreado.
echo.

REM --- 7. Estado geral ---
echo ------------------------------------------------------------
echo   Mudancas pendentes ^(git status resumido^):
echo ------------------------------------------------------------
git status -s
echo.

echo ============================================================
echo   Diagnostico concluido.
echo   Detalhes e comandos de correcao: GUIA-GIT-3LG.md
echo ============================================================

:fim
echo.
pause
