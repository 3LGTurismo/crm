@echo off
REM ============================================================
REM  Corretor Git - 3LG Turismo CRM
REM  Resolve o erro 404 ligando a pasta local ao GitHub e
REM  fazendo o primeiro envio (push) com seguranca.
REM  Coloque na RAIZ do projeto e clique 2x.
REM  Ele PERGUNTA antes de cada passo - nada e feito as cegas.
REM ============================================================
chcp 65001 >nul
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ============================================================
echo   CORRETOR GIT - 3LG TURISMO CRM
echo ============================================================
echo   Pasta: %cd%
echo.

REM --- 1. Git instalado? ---
where git >nul 2>nul
if errorlevel 1 (
  echo [X] Git nao encontrado. Instale em https://git-scm.com/download/win
  goto fim
)
echo [OK] Git instalado.
echo.

REM --- 2. Repositorio iniciado? ---
if not exist ".git" (
  echo [i] Esta pasta ainda nao e um repositorio Git.
  set /p RESP="   Quer iniciar agora e fazer o primeiro commit? (S/N): "
  if /i "!RESP!"=="S" (
    git init
    git add .
    git commit -m "Primeiro commit - 3LG CRM"
    echo [OK] Repositorio iniciado.
  ) else (
    echo [i] Ok, nada feito. Encerrando.
    goto fim
  )
)
echo.

REM --- 3. Garantir que o .env NAO va para o Git ---
if exist ".env" (
  git ls-files --error-unmatch .env >nul 2>nul
  if not errorlevel 1 (
    echo [!] O .env estava sendo versionado. Removendo do Git ^(mantendo no disco^)...
    git rm --cached .env >nul 2>nul
    git commit -m "Remove .env do versionamento (segredos fora do Git)" >nul 2>nul
    echo [OK] .env protegido.
  )
)
if exist ".env.local" (
  git ls-files --error-unmatch .env.local >nul 2>nul
  if not errorlevel 1 (
    echo [!] O .env.local estava sendo versionado. Removendo...
    git rm --cached .env.local >nul 2>nul
    git commit -m "Remove .env.local do versionamento" >nul 2>nul
    echo [OK] .env.local protegido.
  )
)
echo.

REM --- 4. Ver remote atual ---
echo ------------------------------------------------------------
echo   Remote atual:
git remote -v
echo ------------------------------------------------------------
echo.

REM --- 5. Perguntar usuario e repo ---
echo Agora vou ligar esta pasta ao seu repositorio no GitHub.
echo ^(Se o repositorio ainda nao existe, crie primeiro em github.com,
echo   VAZIO, sem README/gitignore/licenca - o projeto ja tem os seus.^)
echo.
set /p GHUSER="   Seu usuario do GitHub: "
set /p GHREPO="   Nome do repositorio (ex.: 3lg-crm): "

if "!GHUSER!"=="" ( echo [X] Usuario vazio. Encerrando. & goto fim )
if "!GHREPO!"=="" ( echo [X] Nome do repo vazio. Encerrando. & goto fim )

set URL=https://github.com/!GHUSER!/!GHREPO!.git
echo.
echo   Vou usar: !URL!
set /p CONF="   Confirma? (S/N): "
if /i not "!CONF!"=="S" ( echo [i] Cancelado. & goto fim )

REM --- 6. Configurar remote (add ou set-url) ---
git remote get-url origin >nul 2>nul
if errorlevel 1 (
  git remote add origin !URL!
  echo [OK] Remote 'origin' criado.
) else (
  git remote set-url origin !URL!
  echo [OK] Remote 'origin' atualizado.
)
echo.

REM --- 7. Garantir branch main e enviar ---
git branch -M main
echo [i] Enviando para o GitHub...
echo     ^(Se pedir senha, cole seu TOKEN pessoal - nao a senha da conta.
echo      Como gerar: veja o Passo 5 do GUIA-GIT-3LG.md^)
echo.
git push -u origin main

if errorlevel 1 (
  echo.
  echo [X] O push falhou. Causas comuns:
  echo     - Repositorio nao existe no GitHub com esse nome exato.
  echo     - Token vencido ou sem permissao 'repo'.
  echo     - Sem internet.
  echo     Detalhes e solucoes: GUIA-GIT-3LG.md
) else (
  echo.
  echo ============================================================
  echo   [OK] Enviado com sucesso! O 404 esta resolvido.
  echo   Repositorio: !URL!
  echo ============================================================
)

:fim
echo.
pause
