# Guia rápido — resolver o erro 404 no Git (3LG Turismo CRM)

O erro **404** no Git quase sempre quer dizer uma coisa: **o repositório remoto não foi encontrado no endereço configurado**. O código do CRM está bem — o problema é a ligação entre a sua pasta local e o servidor (GitHub).

Siga os passos na ordem. Rode os comandos no terminal, **dentro da pasta do projeto**.

---

## Passo 1 — Ver para onde o Git está apontando

```bash
git remote -v
```

Três resultados possíveis:

- **Não aparece nada** → o remote não existe. Vá para o Passo 3.
- **Aparece uma URL** → confira se o usuário e o nome do repositório estão certos. Se houver erro de digitação, vá para o Passo 2.
- **A URL está certa mas ainda dá 404** → o repositório provavelmente não foi criado no GitHub, ou sua credencial venceu. Veja Passo 4 e Passo 5.

---

## Passo 2 — Corrigir a URL do remote (se estiver errada)

```bash
git remote set-url origin https://github.com/SEU-USUARIO/3lg-crm.git
```

Troque `SEU-USUARIO` e `3lg-crm` pelos valores reais. Depois teste:

```bash
git push -u origin main
```

---

## Passo 3 — Criar o repositório no GitHub (primeira vez)

1. Entre em https://github.com e clique em **New repository**.
2. Nome: `3lg-crm` (ou o que preferir). **Deixe-o VAZIO** — sem README, sem .gitignore, sem licença (o projeto já tem os seus).
3. Escolha **Private** (recomendado para um CRM com dados de clientes).
4. Clique em **Create repository**.
5. Na sua pasta local, conecte e envie:

```bash
git remote add origin https://github.com/SEU-USUARIO/3lg-crm.git
git branch -M main
git push -u origin main
```

Se der erro dizendo que o remote `origin` já existe, use o `set-url` do Passo 2 em vez do `add`.

---

## Passo 4 — Repositório existe mas dá 404? Confira o nome exato

O GitHub diferencia maiúsculas/minúsculas e o nome tem que ser idêntico. Abra o repo no navegador e copie a URL da própria barra de endereço — não digite de memória.

---

## Passo 5 — Credencial vencida (repo privado)

Desde 2021 o GitHub **não aceita mais senha** no push. Se a sua expirou, ele responde 404 de propósito (por segurança). Solução — gerar um token:

1. GitHub → **Settings** → **Developer settings** → **Personal access tokens** → **Tokens (classic)** → **Generate new token**.
2. Marque a permissão **repo**.
3. Copie o token gerado (ele só aparece uma vez).
4. No próximo `git push`, quando pedir a senha, **cole o token no lugar da senha**.

No Windows, se ele guardou uma credencial velha, limpe em: Painel de Controle → Gerenciador de Credenciais → Credenciais do Windows → remova a entrada `git:https://github.com`.

---

## Passo 6 (IMPORTANTE) — Proteger os segredos ANTES do primeiro push

Regra 2 do projeto: tokens e service keys **nunca** vão para o Git. Antes de enviar:

1. Copie os arquivos `.gitignore` e `.env.example` (que eu gerei) para a **raiz do projeto**.
2. Se você já tem um arquivo `.env` com valores reais, confirme que ele **não** será enviado:

```bash
git status
```

O `.env` **não** pode aparecer na lista. Se aparecer, é porque ele foi adicionado antes do `.gitignore`. Remova do rastreamento (sem apagar o arquivo do disco):

```bash
git rm --cached .env
git commit -m "Remove .env do versionamento (segredos ficam fora do Git)"
```

3. Faça um commit dos arquivos de configuração:

```bash
git add .gitignore .env.example
git commit -m "Adiciona .gitignore e modelo de variaveis de ambiente"
git push
```

---

## Se ainda não deu certo

Cole para mim, na próxima mensagem:

- O **comando exato** que você rodou.
- A **mensagem de erro completa**.
- A saída de `git remote -v`.

Com isso eu identifico o caso exato e te dou o comando final.
