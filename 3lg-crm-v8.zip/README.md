# CRM 3LG Turismo

CRM de operador único para a 3LG Turismo. Não é um quadro para você administrar —
é uma tela que diz **com quem falar agora e o que dizer**.

> **Repositório privado.** Contém dados operacionais da agência. Não tornar público.

## A ideia

Kanban é ferramenta de gerente olhando time. Aqui não tem time: tem o Leonardo.
Então a tela principal é a **Agora**: um cliente por vez, o motivo de ele estar no topo,
o próximo passo e a mensagem pronta. O funil continua existindo, mas como visão de apoio.

## Rodar

```bash
npm install
npm run dev
```

## Telas

| Tela | Para quê |
|------|----------|
| **Agora** | A fila do dia. Um cliente, um passo, uma mensagem — e o painel do gestor comercial. É onde você trabalha. |
| **Funil** | Visão geral em Kanban, com a regra de bloqueio da proposta. |
| **Tarefas do dia** | O que os agentes criaram enquanto você não estava olhando. |
| **Centro de Comando IA** | Log dos agentes, liga/desliga, backup. |

## As regras que valem dinheiro

**Regra de bloqueio.** Nenhum negócio entra em "Montando Proposta" sem destino, data de
ida e orçamento. Vale no arraste do Kanban e no botão de avançar da tela Agora.

**SLA dinâmico.** Prazo fixo de 48h trata igual quem viaja em 20 dias e quem viaja em
10 meses — o primeiro perde a viagem, o segundo se sente perseguido. O prazo nasce da
distância até a data de ida, ajustado pela etapa. Lead novo: 1 hora.

**Fila de prioridade.** Lead sem contato vem sempre primeiro (velocidade de resposta é o
fator que mais muda resultado). Depois, todo mundo que estourou o prazo. Só então quem
está em dia. Comissão é desempate, nunca fator principal.

**Uma tarefa por gatilho.** Enquanto a tarefa estiver pendente, o agente não cria outra
igual. Sem isso, você acorda com 40 alertas repetidos e desliga o sistema.

## A fila única

A tela Agora não é uma lista de leads: é **uma fila só**, com tudo que merece seu tempo hoje —
venda, cobrança, cuidado de viagem e prospecção — ordenada por camadas:

| # | Camada | O que é |
|---|--------|---------|
| 0 | Crítico agora | Viaja nos próximos dias, ou o bilhete não pode ser emitido |
| 1 | Lead novo | Janela de 1h. Velocidade é o fator nº 1 |
| 2 | Venda atrasada | Estourou o prazo da etapa: dinheiro prestes a ser perdido inteiro |
| 3 | Cobrança | Parcela vencida: dinheiro já conquistado, tolera algumas horas |
| 4 | Cuidado da viagem | Os 15 marcos do pós-venda |
| 5 | Em dia | Acompanhamento normal |
| 6 | Prospecção | Teto de 3/dia, e só quando o resto está em ordem |

**Nada de uma camada de baixo passa na frente de uma de cima.** Prospecção nunca fura fila de
cliente que já está esperando.

## O dinheiro

`status_pagamento` **não é mais um campo digitado**. Ele é lido das parcelas.

Isso importa porque dele dependem as duas travas mais caras do sistema: não enviar o roteiro
final e **não emitir bilhete** sem pagamento. Antes, as duas dependiam de você lembrar de trocar
um campo — e trava que depende de memória humana não é trava. Agora o CRM lê o dinheiro que
realmente entrou.

`comissao` também morreu. Ficou **`custo`** (o que você paga ao fornecedor) como entrada única,
e a margem sai dele: `margem = valor_venda − custo`. Só sabe a comissão da operadora? Lance
`custo = valor_venda − comissão`. Dois campos para a mesma verdade divergem; um, não.

**Por que a margem importa mais do que parece:** é ela que a Fase 3 envia ao Google Ads como
valor da conversão offline. Hoje a conta otimiza por "clicou no WhatsApp" — o lead de R$ 800 e o
de R$ 18.000 valem igual. Com a margem indo de volta, o algoritmo passa a perseguir lucro em vez
de clique. Sem o campo `custo`, essa fase não tem número para enviar.

**O CRM não mente pelo Leonardo.** Nenhuma frase gerada aqui inventa promoção, escassez,
vaga ou tarifa. Nada promete aprovação de visto, entrada em país ou ausência de enjoo.
O gatilho de urgência só é sugerido quando existe risco real e verificável (viagem
próxima) — e mesmo assim vem com o aviso de conferir antes de enviar. Isso é regra de
código, não recomendação: há teste automatizado que falha se um agente escrever
"condição especial" ou "vale até o fim da semana".

## O painel do gestor comercial

Na tela Agora, abaixo dos dados da viagem, existe um segundo cérebro. O ROTEIRO responde
*"em que etapa ele está"*. O painel responde *"QUEM é este cliente e como se fala com ELE"*.

| O que entrega | Como funciona |
|---|---|
| **Temperatura + nota 0-10** | Quente / Morno / Frio, calculada dos dados e dos sinais. Mostra por que deu aquela nota |
| **Perfil** | 14 perfis (família, casal, solo, grupo, melhor idade, econômico, premium, primeira internacional, medo de documentação, câmbio, compara com sites, só preço, sumiu, indeciso) |
| **Gatilhos** | 15 gatilhos de venda, filtrados para aquele cliente, com a frase base pronta |
| **Frases prontas** | Abertura, versão curta para WhatsApp, reforço, pergunta estratégica e fechamento — por perfil |
| **Risco de perda** | Baixo / Médio / Alto, sempre com o motivo |
| **O que você não pode dizer** | Alertas de conformidade na tela, junto do script |
| **Cruzeiro** | 9 perfis próprios + checklist de 15 itens que precisam estar explicados antes de fechar |

**Os sinais são o combustível.** Marque durante a conversa, no bloco "O que ele te disse".
A análise recalcula na hora. Nada é adivinhado de texto livre: chute em perfil gera script
errado, e script errado é pior que script nenhum.

**Não há IA aqui, e isso é de propósito.** É cálculo puro: roda offline, sem chave de API,
sem custo por lead, e devolve sempre a mesma resposta para o mesmo dado. Quando a Fase 4
trouxer o histórico real do WhatsApp, é em `atendimento.js` que a leitura de texto entra —
a estrutura já está pronta para receber.

**Cruzeiro tem um problema que nenhum outro produto tem:** o cliente acha que sabe o que
comprou. Taxa portuária, gorjeta, bebida, internet e excursão não estão no valor que ele
viu — e descobrir isso a bordo vira reclamação e avaliação ruim. Por isso o checklist marca
6 itens como críticos e avisa na tela enquanto não estiverem explicados.

## Agentes

**Agente de Marketing** — nutre e cuida da reputação. Vigia Qualificação parada, sugere
dica de viagem sem falar de preço, e cobra o pedido de avaliação no Google depois da venda.

**Agente de Vendas** — velocidade e fechamento. Alerta lead novo passando de 1h, cobra
follow-up de proposta no silêncio, gera script de fechamento por faixa de orçamento na
entrada em Negociação.

## Estrutura

```
src/
  lib/
    dominio.js        Etapas, roteiro de vendas, scripts, objeções, utilitários
    atendimento.js    Temperatura, perfis, gatilhos, risco, conformidade, frases
    cruzeiro.js       Perfis de cruzeiro, checklist obrigatório, o que nunca prometer
    financeiro.js     Parcelas, status calculado, margem, caixa
    conversao.js      Fase 3: casa gclid + margem para o Google Ads
    fila.js           A fila única em 6 camadas
    jornada.js        Os 15 marcos do pós-venda e suas travas
    prospeccao.js     Os 4 gatilhos de quem procurar sem ter lead
    motor.js          SLA, prioridade, agentes (funções puras)
    persistencia.js   Único ponto de contato: escolhe nuvem ou local sozinho
    nuvem.js          Cliente Supabase (carregado só quando há credenciais)
    dadosIniciais.js  Base de demonstração
    whatsapp.js       Fase 4: fio da conversa, detecção de sinais, janela de 24h
    acesso.js         Login e senha da entrada (hash PBKDF2, criado por você)
    teste.mjs         212 testes das regras de negócio
  telas/              Agora, Funil, Dinheiro, Tarefas, ComandoIA
  componentes/        Modal, painel de atendimento, campos, avisos
migrar-erp.js         Converte um backup do app ERP para este CRM
api/
  cron-agentes.js     Roda os agentes no servidor, com o app fechado
  enviar-conversoes.js Envia gclid + margem ao Google Ads (Fase 3)
site/
  captura-gclid.html  Snippet para o 3lg.com.br capturar o clique
supabase/
  schema.sql          Tabela do CRM na nuvem, com segurança (RLS)
vercel.json           Agendamento do cron (a cada 30 min, horário comercial)
```

O conhecimento de vendas mora em três arquivos e só neles: `dominio.js` (etapas, roteiro,
objeções), `atendimento.js` (quem é o cliente e como falar com ele) e `cruzeiro.js` (o
produto que mais gera dúvida). Mudou o jeito de vender? Mexe lá. As telas não sabem nada
sobre vendas.

## Testes

```bash
node src/lib/teste.mjs
```

212 testes, sem navegador. Cobrem a regra de bloqueio, o SLA dinâmico, a fila em camadas, a
jornada, a prospecção, a temperatura, os perfis, o risco, as parcelas, a margem e — importante —
a conformidade: há teste que **falha de propósito** se algum agente voltar a inventar escassez.


## Fase 2: nuvem e agentes automáticos

Por padrão o CRM roda em **localStorage** — funciona, mas preso a um navegador, e os
agentes só trabalham com a aba aberta. Configurar o Supabase resolve as duas coisas:
dados no celular e no computador, e os agentes rodando por conta própria, mesmo com
tudo fechado. **Nada no app muda para você ativar isso além de preencher um arquivo.**

### Passo 1 — Criar o projeto Supabase (grátis)

1. Entre em supabase.com, crie uma conta e um projeto novo (região: São Paulo).
2. Menu **SQL Editor** → cole o conteúdo de `supabase/schema.sql` → **Run**.
   Isso cria a tabela `crm_estado` com a segurança (RLS) já configurada.

### Passo 2 — Ligar o app à nuvem

1. Copie `.env.example` para `.env.local`.
2. No Supabase: **Settings → API**. Copie **Project URL** e a chave **anon public**.
3. Preencha no `.env.local`:
   ```
   VITE_SUPABASE_URL=https://xxxx.supabase.co
   VITE_SUPABASE_ANON_KEY=a-chave-anon
   ```
4. `npm run dev`. Abra a tela **Comando** — a faixa no topo deve dizer "Dados na nuvem".
   Da primeira vez, o que já estava no navegador sobe sozinho para a nuvem.

Pronto: agora é só publicar (Vercel, Netlify) e abrir o mesmo endereço no celular.

### Passo 3 — Agentes rodando com o app fechado (o cron)

Isto é o que faz a Fase 2 valer a pena. Sem ele, os agentes só rodam com a tela aberta.

1. Publique o projeto na **Vercel** (ela reconhece a pasta `api/` automaticamente).
2. Em **Settings → Environment Variables** da Vercel, adicione (SEM prefixo `VITE_`):
   ```
   SUPABASE_URL=https://xxxx.supabase.co
   SUPABASE_SERVICE_KEY=a-chave-service_role   (Settings → API → service_role)
   SUPABASE_ROW_ID=3lg-turismo
   CRON_SECRET=invente-uma-senha-longa-aqui
   ```
   A `service_role` é secreta e ignora a RLS de propósito — é a máquina agindo sem
   usuário logado. **Nunca** a coloque no frontend nem no Git.
3. No `vercel.json`, troque `COLOQUE_O_CRON_SECRET_AQUI` pela mesma senha do `CRON_SECRET`.
4. Publique. O cron já está agendado: a cada 30 min, das 8h às 20h (horário de Brasília).

Para testar na hora, chame o endereço à mão:
```
https://seu-app.vercel.app/api/cron-agentes?secret=SEU_CRON_SECRET
```
Deve responder algo como `{"ok":true,"novasTarefas":N}`.

### Por que os agentes do servidor não divergem dos da tela

O cron (`api/cron-agentes.js`) importa **o mesmo** `rodarAgentes` de `src/lib/motor.js`
que o app usa. Não há regra reescrita no servidor. Se um dia divergissem seria bug — como
é a mesma função pura, é impossível divergirem. A deduplicação (uma tarefa por gatilho) já
está dentro dela, então o cron não cria alerta repetido do que a tela já criou.


## Fase 3: a margem de volta ao Google Ads

Hoje sua campanha otimiza por "clicou no WhatsApp". Todo lead vale igual — o que fecha
R$ 800 e o que fecha R$ 18.000. O algoritmo não distingue, então gasta a verba
perseguindo volume de clique, não lucro. A Fase 3 corrige isso: quando uma venda fecha,
o CRM manda de volta ao Google o **código do clique** que originou o lead, junto com a
**margem** como valor da conversão. Aí o Ads aprende quais palavras e anúncios trazem
cliente que dá lucro — e passa a gastar ali.

**É por isso que o campo `custo` existia desde a v3.** Sem custo não há margem, e sem
margem esta fase não teria número para enviar.

### O ciclo, em três partes

1. **Capturar** o clique no site (`site/captura-gclid.html`)
2. **Carregar** o código até o CRM (você cola no cadastro do cliente)
3. **Enviar** de volta com a margem quando a venda fecha (`api/enviar-conversoes.js`)

### Passo 1 — Capturar o clique no site

Cole o conteúdo de `site/captura-gclid.html` antes do `</body>` das páginas do
3lg.com.br (via Gerenciador de Arquivos do HostGator; confirme 0644 depois de salvar).

Ele guarda o `gclid` de quem chega pelo anúncio e o injeta em todo link de WhatsApp da
página. Assim, quando o cliente te chama, a primeira mensagem já termina com
`[ref: CÓDIGO]`. Teste acessando `https://www.3lg.com.br/?gclid=TESTE123` e clicando no
botão de WhatsApp.

### Passo 2 — Colar o código no CRM

Ao cadastrar um cliente que veio do Google Ads, um campo **"Código do clique (gclid)"**
aparece. Cole ali a mensagem do WhatsApp inteira — o CRM extrai o código sozinho do
`[ref: ...]`. Só isso.

### Passo 3 — Enviar (a tela faz por você)

Na tela **Dinheiro → Google Ads**, você vê o que está pronto, o que está travado e por
quê. Um botão envia tudo que está pronto. A tela separa em:

- **Prontas**: fecharam, têm o clique e têm margem. Dá para enviar.
- **Travadas: falta o custo**: vieram do anúncio, mas sem custo não há margem. Um clique abre a venda para preencher.
- **Sem clique capturado**: fecharam sem o código. Se vieram do Ads, cole o gclid.
- **Expiradas**: o clique tem mais de 90 dias — o Google não aceita mais.

### Passo 4 — Ligar o envio real ao Google (opcional, mas é o objetivo)

Sem as credenciais do Google Ads, o endpoint roda em **modo ensaio**: mostra exatamente o
que enviaria, sem mandar nada. Dá para validar o ciclo inteiro antes de mexer com a API.

Para o envio real, obtenha (é a parte chata; documentação oficial do Google Ads API):
- **developer token** (conta de API do Google Ads)
- **client_id / client_secret** (projeto OAuth no Google Cloud)
- **refresh_token** (autorização única da sua conta)
- **conversion action ID** — crie no Ads uma conversão de importação chamada
  exatamente `Venda fechada (CRM)`, do tipo "Importar → Cliques", e pegue o ID

Coloque tudo nas variáveis `GOOGLE_ADS_*` da Vercel (Settings → Environment Variables) e
no `vercel.json` troque o placeholder pelo seu `CRON_SECRET`. O cron diário (`12:00 UTC`)
passa a enviar sozinho as conversões novas — e marca cada uma como enviada, para não
repetir.

**Segurança:** todas as credenciais do Google são secretas e ficam SÓ no servidor (sem
prefixo `VITE_`). A API do Google Ads nunca é chamada do navegador — o frontend só
mostra o status e dispara; quem fala com o Google é `api/enviar-conversoes.js`.

## Acesso: login e senha na entrada

A página agora pede **login e senha** antes de abrir. No primeiro acesso o CRM te leva a
**criar** essas credenciais — nada vem embutido no código nem no zip. A senha nunca é
guardada em texto: fica só um **hash PBKDF2-SHA256** com sal aleatório e 150.000 iterações.
A credencial mora dentro do estado (via `persistencia.js`), então, com a nuvem ligada,
acompanha seus dispositivos.

Anote seu login e senha em local seguro: como não guardamos a senha, não há "recuperar" —
o que existe é **Trocar login e senha** no Centro de Comando IA (define novos) e **Bloquear**
na barra lateral (fecha a sessão). Uma atualização da página durante o dia não fica pedindo
senha de novo; fechar o navegador, sim.

**O limite honesto desta tranca.** A verificação roda no navegador e os dados do CRM ainda
não são criptografados. Isso **barra o acesso casual** à página publicada, mas não resiste a
alguém tecnicamente habilidoso com as ferramentas de desenvolvedor. A proteção de verdade é
autenticação no servidor — **Supabase Auth** com a RLS amarrada ao usuário logado — e é o
próximo passo natural depois que a Fase 2 (nuvem) estiver ligada. Até lá, esta é a melhor
relação entre proteger e não atrapalhar um operador só.

## Fase 4: o WhatsApp dentro do card (modo ensaio)

Até aqui, os "sinais" que definem temperatura e perfil eram todos marcados à mão.
A Fase 4 traz a conversa real para dentro do negócio — e transforma o que o cliente
**escreveu** em sugestão de sinal. Nesta entrega ela roda em **modo ensaio**: tudo
funciona sem tocar na Meta, sem custo e sem migrar número. É o mesmo espírito do modo
ensaio do Google Ads: você monta e testa o fluxo inteiro antes de se comprometer.

### O que entra agora

- **A conversa no card.** Na tela Agora, dentro do painel de atendimento, um fio de
  mensagens (você à direita, cliente à esquerda), uma caixa de resposta e o aviso da
  **janela de 24h** da Meta. Responder abre o WhatsApp com o texto pronto (link `wa.me`)
  e registra a mensagem no histórico.
- **Detecção de sinais — sugere, você confirma.** O CRM lê a última mensagem do cliente
  e propõe sinais que já existem (`pediu_preco`, `perguntou_visto`, `medo_enjoo`…),
  cada um mostrando o **trecho** que o disparou. Nada muda a temperatura até você tocar
  para confirmar. Isso é de propósito: o painel sempre disse que *"nada é adivinhado de
  texto livre — chute em perfil gera script errado"*. Detectar uma frase que o cliente
  realmente digitou é leitura; inventar um sinal que ele não deu, seria mentira — e há
  teste que **falha de propósito** se a detecção devolver um sinal sem trecho de origem.
- **Última mensagem e último contato automáticos.** O que você digitava à mão passa a
  vir da própria conversa.
- **Alerta de janela de 24h.** A Meta só permite mensagem livre nas 24h após a última
  fala do cliente. Fora disso, só *template* aprovado (pago). O card avisa antes de você
  escrever — a regra é da Meta, então vale desde o modo ensaio.

### Como testar sem a Meta

No painel de atendimento, abra **"Simular mensagem recebida (modo ensaio)"**, cole o que
o cliente te mandou no WhatsApp e clique em registrar. Ela entra no fio e as sugestões de
sinal aparecem logo acima. A base de demonstração já vem com três conversas prontas — a da
Sueli (Lisboa), por exemplo, sugere marcar "visto" a partir do texto dela.

### O caminho oficial, quando você quiser ligar (fica para uma fase seguinte)

O modo real usa a **WhatsApp Business Cloud API da Meta**, e tem implicações que valem
saber antes de decidir:

- **Custo.** Mensagem iniciada pelo cliente e respondida em até 24h é **grátis** — que é
  o seu caso mais comum. Só disparo ativo fora da janela usa *template* pago (no Brasil,
  ~R$0,04–0,05 por mensagem de utilidade e ~R$0,31–0,38 de marketing, valores de 2026 que
  a Meta reajusta; confirme o vigente).
- **O número migra.** Um número na Cloud API não pode mais ser usado no aplicativo comum
  do WhatsApp. Use um número dedicado para a API, ou perde o app naquele número.
- **Depende da nuvem.** O webhook da Meta grava no servidor, não no navegador — então o
  WhatsApp real exige a **Fase 2 (Supabase)** ligada. O modo ensaio não exige nada disso.

A `whatsapp.js` já está modelada para receber a Cloud API (inclusive deduplicação por
`wamid`, o id da mensagem na Meta), do mesmo jeito que o `atendimento.js` já estava
"pronto para receber" o texto real. Quando você aprovar esse passo, entram os endpoints
`api/whatsapp-webhook.js` (recebe) e `api/whatsapp-enviar.js` (envia) — com os segredos
só no servidor, como todo o resto.

## Vindo do app ERP?

```bash
node migrar-erp.js seu-backup-do-erp.json
```

Gera `estado-crm.json`. Importe em Comando IA → Importar backup. Cotações e vendas viram
`negocios` (eram o mesmo objeto em momentos diferentes), custo e parcelas vêm junto, e cotação
que já virou venda não duplica.

`motor.js` é feito de funções puras: recebem o estado, devolvem tarefas e logs. Isso existe
para que os agentes possam virar um cron no servidor sem reescrita.

## Limites de hoje

Os dados ficam no `localStorage` deste navegador. Portanto: os agentes só rodam com a aba
aberta, e a base não acompanha você no celular. **Baixe o backup toda semana** pelo Centro
de Comando IA. Ambos os limites caem na Fase 2.

## Publicar na Vercel

Importe o repositório em vercel.com. Ela detecta o Vite sozinha (`npm run build` → `dist`).
Cada push na `main` publica.

Para usar `crm.3lg.com.br`: adicione o domínio na Vercel e crie no Zone Editor do cPanel:

| Tipo  | Nome | Valor                |
|-------|------|----------------------|
| CNAME | crm  | cname.vercel-dns.com |

O site em `www.3lg.com.br` continua no HostGator, intocado.

## Roteiro

- [x] **Fase 0** — Funil, regra de bloqueio, agentes.
- [x] **Fase 1** — Modo guiado: fila, SLA dinâmico, roteiro por etapa, objeções, motivo de perda, comissão.
- [ ] **Fase 2** — Supabase. Base fora do navegador, agentes em cron, acesso pelo celular.
- [ ] **Fase 3** — Captura de lead pelo site com `gclid` + conversão offline para o Google Ads (conta 7735794813), usando comissão como valor.
- [~] **Fase 4** — Conversa dentro do card + detecção de sinais + janela de 24h, em **modo ensaio**. Cloud API real (webhook + envio) fica para quando você aprovar a integração com a Meta.
- [ ] **Fase 5** — IA lendo o histórico real para qualificar e escrever a mensagem.
