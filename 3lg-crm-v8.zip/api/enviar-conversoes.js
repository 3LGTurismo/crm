/* ============================================================
   ENVIO DE CONVERSÃO OFFLINE — servidor.

   Roda no servidor porque falar com o Google Ads exige credenciais
   secretas (developer token, refresh token) que NUNCA podem ir para
   o navegador. Recebe do cron (ou de um clique manual no CRM) a lista
   de conversões prontas e as envia via Google Ads API.

   Fluxo completo da Fase 3:
   1. Site captura o gclid (site/captura-gclid.html)
   2. Você cola o gclid no cadastro do cliente no CRM
   3. Venda fecha -> conversao.js marca como "pronta"
   4. Este endpoint envia gclid + margem ao Google
   5. O algoritmo do Ads aprende a perseguir lucro, não clique

   Proteção: mesmo padrão do cron — header x-cron-secret.

   Sobre as credenciais do Google Ads: são chatas de obter (developer
   token, OAuth, customer id). O README traz o passo a passo. Enquanto
   não estiverem configuradas, este endpoint responde em "modo ensaio":
   valida e mostra o que ENVIARIA, sem mandar nada. Assim você testa o
   ciclo inteiro antes de mexer com a API do Google.
   ============================================================ */

import { createClient } from "@supabase/supabase-js";
import { montarConversao, statusConversao, STATUS_CONVERSAO } from "../src/lib/conversao.js";

const ID_ESTADO = process.env.SUPABASE_ROW_ID || "3lg-turismo";

export default async function handler(req, res) {
  // 1. Autorização
  const segredo = req.headers["x-cron-secret"] || req.query?.secret;
  if (!process.env.CRON_SECRET || segredo !== process.env.CRON_SECRET) {
    return res.status(401).json({ erro: "não autorizado" });
  }

  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_KEY;
  if (!url || !key) return res.status(500).json({ erro: "Supabase não configurado" });

  const sb = createClient(url, key, { auth: { persistSession: false } });

  try {
    // 2. Lê o estado
    const { data, error } = await sb.from("crm_estado").select("dados").eq("id", ID_ESTADO).maybeSingle();
    if (error) throw error;
    const estado = data?.dados;
    if (!estado) return res.status(200).json({ ok: true, mensagem: "Sem estado salvo." });

    // 3. Junta tudo que está pronto para enviar
    const clientePor = (id) => (estado.clientes || []).find((c) => c.id === id);
    const prontas = [];
    (estado.negocios || []).forEach((n) => {
      const c = clientePor(n.cliente_id);
      if (statusConversao(n, c) === STATUS_CONVERSAO.PRONTA) {
        const conv = montarConversao(n, c);
        if (conv) prontas.push(conv);
      }
    });

    if (prontas.length === 0) {
      return res.status(200).json({ ok: true, enviadas: 0, mensagem: "Nada novo para enviar." });
    }

    // 4. Modo ensaio: sem credenciais do Google, não envia — só mostra.
    const temGoogle =
      process.env.GOOGLE_ADS_DEVELOPER_TOKEN &&
      process.env.GOOGLE_ADS_REFRESH_TOKEN &&
      process.env.GOOGLE_ADS_CUSTOMER_ID;

    if (!temGoogle) {
      return res.status(200).json({
        ok: true,
        modo: "ensaio",
        mensagem:
          "Credenciais do Google Ads não configuradas. Estas conversões ESTÃO prontas e seriam enviadas — configure as variáveis GOOGLE_ADS_* para ativar o envio real.",
        enviariaAgora: prontas.length,
        prontas: prontas.map((c) => ({
          cliente: c._cliente,
          destino: c._destino,
          venda: c._venda,
          margemEnviada: c.conversionValue,
          gclid: c.gclid.slice(0, 12) + "…",
        })),
      });
    }

    // 5. Envio real ao Google Ads API.
    const resultado = await enviarAoGoogle(prontas);

    // 6. Marca no estado o que foi aceito, para não reenviar.
    const idsEnviados = new Set(resultado.aceitos.map((r) => r.negocio_id));
    const novoEstado = {
      ...estado,
      negocios: estado.negocios.map((n) =>
        idsEnviados.has(n.id)
          ? {
              ...n,
              conversao: {
                enviada: true,
                enviada_em: new Date().toISOString(),
                valor: prontas.find((p) => p.negocio_id === n.id)?.conversionValue,
              },
            }
          : n
      ),
      logs: [
        {
          id: Math.random().toString(36).slice(2),
          nome_agente: "Conversão Ads",
          acao_realizada: `${resultado.aceitos.length} conversão(ões) enviada(s) ao Google Ads.${
            resultado.recusados.length ? ` ${resultado.recusados.length} recusada(s).` : ""
          }`,
          timestamp: new Date().toISOString(),
        },
        ...(estado.logs || []),
      ].slice(0, 300),
    };

    await sb
      .from("crm_estado")
      .upsert({ id: ID_ESTADO, dados: novoEstado, atualizado_em: new Date().toISOString() }, { onConflict: "id" });

    return res.status(200).json({
      ok: true,
      enviadas: resultado.aceitos.length,
      recusadas: resultado.recusados.length,
      detalheRecusas: resultado.recusados,
    });
  } catch (e) {
    console.error("Envio de conversão falhou:", e);
    return res.status(500).json({ erro: String(e.message || e) });
  }
}

/* ------------------------------------------------------------
   Chamada à Google Ads API (uploadClickConversions).
   Usa REST direto — sem SDK pesado — com um access_token obtido
   do refresh_token via OAuth.
   ------------------------------------------------------------ */
async function enviarAoGoogle(conversoes) {
  const accessToken = await obterAccessToken();
  const customerId = process.env.GOOGLE_ADS_CUSTOMER_ID.replace(/-/g, "");
  const devToken = process.env.GOOGLE_ADS_DEVELOPER_TOKEN;
  const loginCustomerId = (process.env.GOOGLE_ADS_LOGIN_CUSTOMER_ID || customerId).replace(/-/g, "");

  const endpoint = `https://googleads.googleapis.com/v17/customers/${customerId}:uploadClickConversions`;

  const body = {
    conversions: conversoes.map((c) => ({
      gclid: c.gclid,
      conversionAction: `customers/${customerId}/conversionActions/${process.env.GOOGLE_ADS_CONVERSION_ACTION_ID}`,
      conversionDateTime: c.conversionDateTime,
      conversionValue: c.conversionValue,
      currencyCode: c.currencyCode,
    })),
    partialFailure: true, // uma conversão ruim não derruba o lote inteiro
  };

  const resp = await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "developer-token": devToken,
      "login-customer-id": loginCustomerId,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  const json = await resp.json();
  if (!resp.ok) throw new Error(json.error?.message || `Google Ads respondeu ${resp.status}`);

  // partial_failure_error lista o que foi recusado; o resto foi aceito.
  const recusados = [];
  const erros = json.partialFailureError?.details || [];
  erros.forEach((d) => {
    (d.errors || []).forEach((e) => recusados.push({ motivo: e.message }));
  });

  const aceitos = conversoes
    .filter((_, i) => !recusadoNoIndice(json, i))
    .map((c) => ({ negocio_id: c.negocio_id }));

  return { aceitos, recusados };
}

function recusadoNoIndice(json, i) {
  const detalhes = json.partialFailureError?.details || [];
  return detalhes.some((d) =>
    (d.errors || []).some((e) => (e.location?.fieldPathElements || []).some((f) => f.index === i))
  );
}

async function obterAccessToken() {
  const resp = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: process.env.GOOGLE_ADS_CLIENT_ID,
      client_secret: process.env.GOOGLE_ADS_CLIENT_SECRET,
      refresh_token: process.env.GOOGLE_ADS_REFRESH_TOKEN,
      grant_type: "refresh_token",
    }),
  });
  const json = await resp.json();
  if (!resp.ok) throw new Error(json.error_description || "Falha ao renovar token do Google");
  return json.access_token;
}
