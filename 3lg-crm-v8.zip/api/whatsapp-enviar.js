/* ============================================================
   ENVIO DE MENSAGEM PELO WHATSAPP — servidor (Fase 4).

   Roda no servidor porque falar com a Cloud API da Meta exige um
   ACCESS TOKEN secreto que NUNCA pode ir para o navegador. Recebe do
   CRM um { negocioId, telefone, texto } e envia a mensagem.

   Este endpoint é o par do "Enviar pelo WhatsApp" do card. Hoje, no
   modo ensaio, o card já abre o wa.me no navegador (Caminho 1). Quando
   você ativar a Cloud API, o mesmo botão pode passar a chamar AQUI e o
   envio vira automático, sem abrir aba.

   MODO ENSAIO (igual ao da Fase 3):
   Sem WHATSAPP_ACCESS_TOKEN / WHATSAPP_PHONE_NUMBER_ID configurados,
   este endpoint NÃO fala com a Meta — ele valida e devolve o payload
   que ENVIARIA. Assim você testa o ciclo inteiro antes de contratar e
   aprovar a conta na Meta (que tem custo por conversa).

   REGRA Nº 1 (o CRM não mente pelo Leonardo): este endpoint é um
   carteiro. Ele envia EXATAMENTE o texto que recebe — quem escreve é
   você (ou as frases do perfil que você copiou). Ele nunca inventa
   promoção, vaga ou tarifa. A montagem do payload é a função pura
   montarPayloadEnvio, coberta por teste que falha se o texto for
   alterado.

   Proteção: mesmo padrão dos outros endpoints — header x-cron-secret.
   ============================================================ */

import { montarPayloadEnvio, normalizarTelefone } from "../src/lib/whatsapp.js";

const VERSAO_API = "v21.0"; // versão da Graph API da Meta

export default async function handler(req, res) {
  // Só aceita POST — enviar é uma ação, não uma leitura.
  if (req.method !== "POST") {
    return res.status(405).json({ erro: "use POST" });
  }

  // 1. Autorização (mesma senha do cron/conversões).
  const segredo = req.headers["x-cron-secret"] || req.query?.secret;
  if (!process.env.CRON_SECRET || segredo !== process.env.CRON_SECRET) {
    return res.status(401).json({ erro: "não autorizado" });
  }

  // 2. Lê e valida a entrada. Sem texto ou sem telefone, não há o que fazer.
  const corpo = req.body || {};
  const telefone = normalizarTelefone(corpo.telefone);
  const texto = String(corpo.texto ?? "").trim();
  if (!telefone) return res.status(400).json({ erro: "telefone ausente ou inválido" });
  if (!texto) return res.status(400).json({ erro: "texto vazio — nada a enviar" });

  // 3. Monta o payload (função pura, testada, carteiro fiel).
  const payload = montarPayloadEnvio({ telefone, texto });

  // 4. Modo ensaio: sem credenciais da Meta, não envia — só mostra.
  const token = process.env.WHATSAPP_ACCESS_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (!token || !phoneId) {
    return res.status(200).json({
      ok: true,
      modo: "ensaio",
      mensagem:
        "Cloud API da Meta não configurada. Esta mensagem SERIA enviada — configure WHATSAPP_ACCESS_TOKEN e WHATSAPP_PHONE_NUMBER_ID para ativar o envio real. Até lá, use o botão que abre o WhatsApp (wa.me).",
      enviaria: payload,
    });
  }

  // 5. Envio real pela Cloud API.
  try {
    const resp = await fetch(`https://graph.facebook.com/${VERSAO_API}/${phoneId}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });
    const json = await resp.json();
    if (!resp.ok) {
      // A Meta devolve o motivo em error.message — repassa para o CRM
      // saber POR QUE não foi (ex.: fora da janela de 24h).
      return res.status(resp.status).json({
        ok: false,
        erro: json?.error?.message || `Meta respondeu ${resp.status}`,
        detalhe: json?.error,
      });
    }
    // wamid da mensagem enviada — devolvido para o fio guardar e não
    // duplicar quando o webhook de status ecoar o mesmo id.
    const wamid = json?.messages?.[0]?.id || "";
    return res.status(200).json({ ok: true, wamid, resposta: json });
  } catch (e) {
    console.error("Envio WhatsApp falhou:", e);
    return res.status(500).json({ erro: String(e.message || e) });
  }
}
