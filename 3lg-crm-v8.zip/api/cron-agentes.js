/* ============================================================
   CRON DOS AGENTES — o que faz a Fase 2 valer a pena.

   Roda no servidor, sozinho, mesmo com o app e o navegador
   fechados. Lê o estado da nuvem, roda EXATAMENTE o mesmo
   `rodarAgentes` do cliente, e grava de volta as tarefas novas.

   Nenhuma regra é reescrita aqui. O motor é puro e compartilhado —
   é por isso que o SLA, a cobrança de parcela vencida e o alerta de
   bilhete continuam idênticos ao que você vê na tela. Se algum dia
   divergissem, seria bug; como é a mesma função, não podem divergir.

   Onde roda: Vercel Cron, Netlify Scheduled Functions, Supabase Edge
   Functions ou um cron de VPS chamando este endpoint. Sugestão de
   frequência: a cada 30 min em horário comercial. Fora dele não
   precisa — ninguém vai responder um lead às 3h da manhã.

   Proteção: exige o header `x-cron-secret` igual a CRON_SECRET.
   Sem isso, qualquer um na internet dispararia seus agentes.
   ============================================================ */

import { createClient } from "@supabase/supabase-js";
import { rodarAgentes } from "../src/lib/motor.js";

const ID_ESTADO = process.env.SUPABASE_ROW_ID || "3lg-turismo";

export default async function handler(req, res) {
  // 1. Só o cron autorizado entra.
  const segredo = req.headers["x-cron-secret"] || req.query?.secret;
  if (!process.env.CRON_SECRET || segredo !== process.env.CRON_SECRET) {
    return res.status(401).json({ erro: "não autorizado" });
  }

  // 2. Credenciais de servidor (service_role): ignora RLS de propósito,
  //    porque aqui não há usuário logado — é a máquina agindo.
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_KEY;
  if (!url || !key) {
    return res.status(500).json({ erro: "SUPABASE_URL/SUPABASE_SERVICE_KEY ausentes" });
  }

  const sb = createClient(url, key, { auth: { persistSession: false } });

  try {
    // 3. Lê o estado.
    const { data, error } = await sb.from("crm_estado").select("dados").eq("id", ID_ESTADO).maybeSingle();
    if (error) throw error;

    const estado = data?.dados;
    if (!estado) {
      return res.status(200).json({ ok: true, mensagem: "Nenhum estado salvo ainda. Nada a fazer." });
    }

    // 4. Roda os MESMOS agentes do cliente.
    const { tarefas, logs } = rodarAgentes(estado);

    if (tarefas.length === 0) {
      return res.status(200).json({ ok: true, novasTarefas: 0, mensagem: "Tudo dentro do prazo." });
    }

    // 5. Grava de volta. A deduplicação já está dentro de rodarAgentes
    //    (uma tarefa por gatilho), então isto não cria alerta repetido.
    const novoEstado = {
      ...estado,
      tarefas: [...tarefas, ...(estado.tarefas || [])],
      logs: [
        ...logs.reverse(),
        ...(estado.logs || []),
      ].slice(0, 300),
    };

    const { error: erroSalvar } = await sb
      .from("crm_estado")
      .upsert(
        { id: ID_ESTADO, dados: novoEstado, atualizado_em: new Date().toISOString() },
        { onConflict: "id" }
      );
    if (erroSalvar) throw erroSalvar;

    return res.status(200).json({
      ok: true,
      novasTarefas: tarefas.length,
      gatilhos: tarefas.map((t) => t.gatilho),
    });
  } catch (e) {
    console.error("Cron dos agentes falhou:", e);
    return res.status(500).json({ erro: String(e.message || e) });
  }
}
