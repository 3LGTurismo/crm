/* ============================================================
   WEBHOOK DO WHATSAPP — servidor (Fase 4).

   É o endereço que a Meta chama quando o cliente te manda uma mensagem.
   Roda no servidor (não no navegador) por dois motivos: guarda o
   APP SECRET para conferir a assinatura, e grava no Supabase com o app
   fechado — do mesmo jeito que o cron dos agentes.

   Faz duas coisas, conforme o método:
   - GET  -> a "aperto de mão" de verificação que a Meta exige ao
             cadastrar o webhook (devolve o hub.challenge se o
             verify_token bater com o seu).
   - POST -> a mensagem em si: confere a assinatura, extrai o texto,
             descobre a qual negócio pertence (pelo telefone) e anexa
             ao fio da conversa daquele card.

   A parte "chata" (ler payload, achar o negócio) é feita por funções
   PURAS em src/lib/whatsapp.js, cobertas por teste. Aqui só tem rede,
   segredo e assinatura.

   MODO ENSAIO: o recebimento AUTOMÁTICO depende da Fase 2 (Supabase)
   ligada — é onde a mensagem é gravada com o app fechado. Sem Supabase,
   o webhook ainda responde 200 e devolve o que LERIA (para você testar
   o parse), mas quem alimenta o fio no dia a dia é o "Simular mensagem
   recebida" do card. Com Supabase ligado + credenciais da Meta, passa a
   gravar sozinho.

   REGRA Nº 1: o webhook só registra o que o cliente REALMENTE mandou.
   Mensagem de tipo que não sabemos ler (áudio, imagem) entra como
   "[áudio recebido]" honesto, nunca com um conteúdo inventado.
   ============================================================ */

import crypto from "crypto";
import { createClient } from "@supabase/supabase-js";
import {
  extrairMensagensWebhook,
  acharNegocioPorTelefone,
  novaMensagem,
  anexarMensagem,
  DIRECAO,
} from "../src/lib/whatsapp.js";

const ID_ESTADO = process.env.SUPABASE_ROW_ID || "3lg-turismo";

// Precisamos do corpo CRU (bytes originais) para conferir a assinatura
// da Meta — por isso desligamos o parser automático do body.
export const config = { api: { bodyParser: false } };

export default async function handler(req, res) {
  // ---------- GET: verificação do webhook (feita uma vez, no cadastro) ----------
  if (req.method === "GET") {
    const modo = req.query["hub.mode"];
    const token = req.query["hub.verify_token"];
    const challenge = req.query["hub.challenge"];
    if (modo === "subscribe" && token && token === process.env.WHATSAPP_VERIFY_TOKEN) {
      return res.status(200).send(challenge);
    }
    return res.status(403).json({ erro: "verify_token não confere" });
  }

  if (req.method !== "POST") return res.status(405).json({ erro: "método não suportado" });

  // ---------- POST: mensagem recebida ----------
  const raw = await lerCorpoCru(req);

  // Confere a assinatura, SE o app secret estiver configurado. A Meta
  // assina o corpo com HMAC-SHA256; sem isso, qualquer um poderia forjar
  // uma mensagem. No modo ensaio (sem APP_SECRET) pulamos a conferência.
  if (process.env.WHATSAPP_APP_SECRET) {
    if (!assinaturaValida(req, raw, process.env.WHATSAPP_APP_SECRET)) {
      return res.status(401).json({ erro: "assinatura inválida" });
    }
  }

  let payload;
  try {
    payload = JSON.parse(raw || "{}");
  } catch {
    return res.status(400).json({ erro: "corpo não é JSON" });
  }

  const recebidas = extrairMensagensWebhook(payload);

  // Sem Supabase, não há onde gravar com o app fechado: respondemos 200
  // (a Meta exige 200, senão reenvia) e devolvemos o que LERÍAMOS.
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_KEY;
  if (!url || !key) {
    return res.status(200).json({
      ok: true,
      modo: "ensaio",
      mensagem:
        "Supabase não configurado — o recebimento automático precisa da Fase 2 ligada. Estas mensagens SERIAM registradas no fio.",
      leu: recebidas,
    });
  }

  if (recebidas.length === 0) {
    // Pode ser um evento de status (entregue/lido), não uma mensagem.
    return res.status(200).json({ ok: true, registradas: 0 });
  }

  try {
    const sb = createClient(url, key, { auth: { persistSession: false } });
    const { data, error } = await sb.from("crm_estado").select("dados").eq("id", ID_ESTADO).maybeSingle();
    if (error) throw error;
    const estado = data?.dados;
    if (!estado) return res.status(200).json({ ok: true, registradas: 0, mensagem: "Sem estado salvo." });

    let registradas = 0;
    const negocios = estado.negocios || [];
    const clientes = estado.clientes || [];

    for (const r of recebidas) {
      const negId = acharNegocioPorTelefone(negocios, clientes, r.telefone);
      if (!negId) continue; // telefone sem cliente cadastrado: não inventa negócio.

      const idx = negocios.findIndex((n) => n.id === negId);
      if (idx < 0) continue;

      // Texto honesto: o que dá para ler, lê; o que não dá, marca o tipo.
      const texto = r.texto || `[${r.tipo} recebido]`;
      const msg = novaMensagem({ direcao: DIRECAO.ENTRADA, texto, ts: r.ts, wamid: r.wamid });
      const fio = anexarMensagem(negocios[idx].conversa, msg);
      if (fio === negocios[idx].conversa) continue; // dedup pelo wamid: já estava lá.

      negocios[idx] = {
        ...negocios[idx],
        conversa: fio,
        ultima_mensagem: texto,
        ultima_interacao: r.ts,
      };
      registradas++;
    }

    if (registradas > 0) {
      const novoEstado = { ...estado, negocios };
      await sb
        .from("crm_estado")
        .upsert({ id: ID_ESTADO, dados: novoEstado, atualizado_em: new Date().toISOString() }, { onConflict: "id" });
    }

    return res.status(200).json({ ok: true, registradas });
  } catch (e) {
    console.error("Webhook WhatsApp falhou:", e);
    // Mesmo em erro, responde 200 para a Meta não entrar em loop de reenvio;
    // o erro fica no log do servidor para você investigar.
    return res.status(200).json({ ok: false, erro: String(e.message || e) });
  }
}

/* ------------------------------------------------------------
   Auxiliares de servidor (não puros: mexem em stream e crypto).
   ------------------------------------------------------------ */

function lerCorpoCru(req) {
  return new Promise((resolve, reject) => {
    let dados = "";
    req.on("data", (chunk) => (dados += chunk));
    req.on("end", () => resolve(dados));
    req.on("error", reject);
  });
}

function assinaturaValida(req, raw, appSecret) {
  const cabecalho = req.headers["x-hub-signature-256"] || "";
  const esperado = "sha256=" + crypto.createHmac("sha256", appSecret).update(raw).digest("hex");
  // timingSafeEqual evita vazar informação pelo tempo de comparação.
  const a = Buffer.from(cabecalho);
  const b = Buffer.from(esperado);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
