#!/usr/bin/env node
/* ============================================================
   MIGRAR ERP -> CRM

   Converte um backup exportado pelo app ERP (o .json do botão
   "Exportar backup") para o formato deste CRM.

   Uso:
     node migrar-erp.js 3lg-erp-backup-2026-07-17.json
     node migrar-erp.js backup.json --saida estado-crm.json

   Depois: abra o CRM, vá em Comando IA -> Importar backup e
   selecione o arquivo gerado.

   O que ele faz:
   - cotações e vendas do ERP viram `negocios` (eram o mesmo objeto
     em momentos diferentes)
   - os status do ERP viram etapas do funil
   - `custo` e `parcelas` vêm junto
   - tarefas do ERP viram tarefas do CRM

   O que ele NÃO inventa: sinais de atendimento, perfil, fornecedores
   e marcos da jornada nascem vazios. Preencher isso com chute seria
   pior do que deixar em branco.
   ============================================================ */

import { readFileSync, writeFileSync } from "node:fs";

const uid = () => Math.random().toString(36).slice(2, 10);
const hoje = () => new Date().toISOString().slice(0, 10);
const agora = () => new Date().toISOString();

const ETAPA_POR_STATUS = {
  nova: "Novo Lead",
  negociando: "Qualificação",
  enviada: "Proposta Enviada",
  fechada: "Fechado",
  perdida: "Perdido",
};

const TIPO_POR_TIPO = {
  "Pacote nacional": "Pacote nacional",
  "Pacote internacional": "Pacote internacional",
  Cruzeiro: "Cruzeiro",
  "Passagem aérea": "Aéreo",
  Rodoviário: "Rodoviário",
  Hospedagem: "Hospedagem",
  Excursão: "Pacote nacional",
  "Seguro viagem": "Outro",
  "Roteiro personalizado": "Outro",
};

function migrar(erp) {
  const clientes = [];
  const idPorNome = new Map();

  const acharOuCriarCliente = (clienteId, nome) => {
    if (clienteId) {
      const original = (erp.clientes || []).find((c) => c.id === clienteId);
      if (original) {
        const existente = clientes.find((c) => c.origem_erp === original.id);
        if (existente) return existente.id;
        const novo = {
          id: uid(),
          origem_erp: original.id,
          nome: original.nome,
          whatsapp: original.whatsapp || "",
          email: original.email || "",
          origem: "WhatsApp",
          aniversario: null,
          prospeccao_feita: {},
          notas: [original.cidade, original.obs].filter(Boolean).join(" · "),
        };
        clientes.push(novo);
        idPorNome.set(original.nome.toLowerCase(), novo.id);
        return novo.id;
      }
    }
    // negócio sem cadastro: cria cliente pelo nome digitado
    const chave = (nome || "").toLowerCase().trim();
    if (!chave) return null;
    if (idPorNome.has(chave)) return idPorNome.get(chave);
    const novo = {
      id: uid(),
      nome: nome.trim(),
      whatsapp: "",
      email: "",
      origem: "WhatsApp",
      aniversario: null,
      prospeccao_feita: {},
      notas: "",
    };
    clientes.push(novo);
    idPorNome.set(chave, novo.id);
    return novo.id;
  };

  const negocios = [];

  // Vendas primeiro: se a cotação virou venda, a venda manda.
  const cotacoesFechadas = new Set();

  (erp.vendas || []).forEach((v) => {
    const cliente_id = acharOuCriarCliente(v.clienteId, v.clienteNome);
    if (!cliente_id) return;
    if (v.cotacaoId) cotacoesFechadas.add(v.cotacaoId);

    negocios.push({
      id: uid(),
      cliente_id,
      destino: v.destino || "",
      tipo: TIPO_POR_TIPO[v.tipo] || "Outro",
      etapa_funil: "Fechado",
      data_ida: v.embarque || "",
      data_volta: v.retorno || "",
      num_pessoas: 0,
      orcamento: Number(v.valorVenda) || 0,
      valor_venda: Number(v.valorVenda) || 0,
      custo: Number(v.custo) || 0,
      parcelas: (v.parcelas || []).map((p) => ({
        id: uid(),
        n: p.n,
        valor: Number(p.valor) || 0,
        vencimento: p.vencimento,
        pago: Boolean(p.pago),
        pago_em: p.pagoEm || null,
      })),
      localizador: v.localizador || "",
      data_fechamento: v.criadoEm || hoje(),
      motivo_viagem: "",
      motivo_perda: "",
      notas: [v.obs, v.fornecedor ? `Fornecedor no ERP: ${v.fornecedor}` : ""].filter(Boolean).join("\n"),
      checklist: {},
      checklist_jornada: {},
      fornecedores: [],
      adiado_ate: null,
      ultima_interacao: agora(),
      sinais: {},
      perfil_manual: "",
      ultima_mensagem: "",
      cruzeiro: {},
      checklist_cruzeiro: {},
    });
  });

  (erp.cotacoes || []).forEach((c) => {
    if (cotacoesFechadas.has(c.id)) return; // já virou venda
    const cliente_id = acharOuCriarCliente(c.clienteId, c.clienteNome);
    if (!cliente_id) return;

    negocios.push({
      id: uid(),
      cliente_id,
      destino: c.destino || "",
      tipo: TIPO_POR_TIPO[c.tipo] || "Outro",
      etapa_funil: ETAPA_POR_STATUS[c.status] || "Novo Lead",
      data_ida: c.dataViagem || "",
      data_volta: "",
      num_pessoas: 0,
      orcamento: Number(c.valorEstimado) || 0,
      valor_venda: 0,
      custo: 0,
      parcelas: [],
      localizador: "",
      data_fechamento: "",
      motivo_viagem: "",
      motivo_perda: c.status === "perdida" ? "Outro" : "",
      notas: c.obs || "",
      checklist: {},
      checklist_jornada: {},
      fornecedores: [],
      adiado_ate: null,
      ultima_interacao: agora(),
      sinais: {},
      perfil_manual: "",
      ultima_mensagem: "",
      cruzeiro: {},
      checklist_cruzeiro: {},
    });
  });

  const tarefas = (erp.tarefas || [])
    .filter((t) => !t.feita)
    .map((t) => ({
      id: uid(),
      negocio_id: null,
      tipo: "WhatsApp",
      gatilho: "importada_erp",
      agente: "Importada do ERP",
      status: "Pendente",
      criada_em: agora(),
      data_vencimento: t.vencimento || hoje(),
      descricao: t.titulo,
      sugestao: t.obs || "",
    }));

  return {
    clientes: clientes.map(({ origem_erp, ...c }) => c),
    negocios,
    tarefas,
    logs: [
      {
        id: uid(),
        data: agora(),
        nome_agente: "Sistema",
        acao_realizada: `Importado do ERP: ${clientes.length} cliente(s), ${negocios.length} negócio(s), ${tarefas.length} tarefa(s).`,
      },
    ],
    agentes: { marketing: true, vendas: true, operacoes: true },
  };
}

/* -------------------- execução -------------------- */

const args = process.argv.slice(2);
const entrada = args.find((a) => !a.startsWith("--"));
const iSaida = args.indexOf("--saida");
const saida = iSaida !== -1 ? args[iSaida + 1] : "estado-crm.json";

if (!entrada) {
  console.error("Uso: node migrar-erp.js <backup-do-erp.json> [--saida estado-crm.json]");
  process.exit(1);
}

let erp;
try {
  erp = JSON.parse(readFileSync(entrada, "utf-8"));
} catch (e) {
  console.error(`Não consegui ler "${entrada}": ${e.message}`);
  process.exit(1);
}

if (!erp.clientes && !erp.vendas && !erp.cotacoes) {
  console.error("Este arquivo não parece um backup do ERP (não tem clientes, vendas nem cotações).");
  process.exit(1);
}

const estado = migrar(erp);
writeFileSync(saida, JSON.stringify(estado, null, 2), "utf-8");

const fechados = estado.negocios.filter((n) => n.etapa_funil === "Fechado").length;
const comParcela = estado.negocios.filter((n) => n.parcelas.length > 0).length;
const semCusto = estado.negocios.filter((n) => n.etapa_funil === "Fechado" && !n.custo).length;

console.log(`
✅ Migração concluída: ${saida}

   ${estado.clientes.length} cliente(s)
   ${estado.negocios.length} negócio(s) — ${fechados} fechado(s)
   ${comParcela} com parcelas
   ${estado.tarefas.length} tarefa(s) pendente(s)

Agora abra o CRM em Comando IA → Importar backup e selecione esse arquivo.
`);

if (semCusto > 0) {
  console.log(`⚠️  ${semCusto} venda(s) fechada(s) sem custo informado.
   Sem custo, a margem fica igual ao valor da venda — e é a margem que
   a Fase 3 envia ao Google Ads. Vale preencher antes de ligar a conversão offline.
`);
}
