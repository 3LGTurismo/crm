-- ============================================================
-- CRM 3LG — schema do Supabase
--
-- Cole isto no SQL Editor do Supabase (Dashboard → SQL Editor)
-- e clique em Run. Cria a tabela única onde o CRM inteiro mora.
-- ============================================================

create table if not exists crm_estado (
  id            text primary key,
  dados         jsonb not null default '{}'::jsonb,
  atualizado_em timestamptz not null default now()
);

-- ------------------------------------------------------------
-- Row Level Security
--
-- A chave anon do app é pública (vai no navegador). A RLS é a
-- proteção real. Como é um operador só, a política abaixo libera
-- leitura e escrita para a chave anon APENAS na linha da 3LG.
--
-- O cron do servidor usa a service_role, que ignora RLS — por isso
-- ele funciona mesmo sem ninguém logado.
-- ------------------------------------------------------------

alter table crm_estado enable row level security;

-- Leitura da própria linha
create policy "3lg lê seu estado"
  on crm_estado for select
  using ( id = '3lg-turismo' );

-- Inserção da própria linha
create policy "3lg cria seu estado"
  on crm_estado for insert
  with check ( id = '3lg-turismo' );

-- Atualização da própria linha
create policy "3lg atualiza seu estado"
  on crm_estado for update
  using ( id = '3lg-turismo' )
  with check ( id = '3lg-turismo' );

-- ------------------------------------------------------------
-- Quando a agência virar mais de uma pessoa:
-- troque as políticas por auth.uid() = id, ative o Auth do
-- Supabase e passe a usar o id do usuário como chave da linha.
-- O app já foi escrito para isso: veja VITE_SUPABASE_ROW_ID.
-- ------------------------------------------------------------
