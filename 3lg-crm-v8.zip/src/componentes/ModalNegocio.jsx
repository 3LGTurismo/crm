import React, { useState } from "react";
import { X, Lock, Plus, Trash2, AlertTriangle, Package } from "lucide-react";
import { Campo, Seletor, Secao, AreaTexto } from "./ui.jsx";
import { TIPOS_VIAGEM, ORIGENS, MOTIVOS_PERDA, camposFaltando, uid, hojeISO } from "../lib/dominio.js";
import { STATUS_FORNECEDOR, fornecedorAtrasado } from "../lib/jornada.js";
import { gerarParcelas, statusPagamento, margem, margemPercentual, divergenciaParcelas, totalParcelado } from "../lib/financeiro.js";
import { extrairGclid } from "../lib/conversao.js";
import { ehCruzeiro, TIPOS_CABINE } from "../lib/cruzeiro.js";

export default function ModalNegocio({ modo, negocio, cliente, onSalvar, onExcluir, onFechar }) {
  const [f, setF] = useState({
    id: negocio?.id || null,
    cliente_id: negocio?.cliente_id || null,
    nome: cliente?.nome || "",
    whatsapp: cliente?.whatsapp || "",
    email: cliente?.email || "",
    origem: cliente?.origem || "WhatsApp",
    gclid: cliente?.gclid || "",
    gclid_em: cliente?.gclid_em || null,
    destino: negocio?.destino || "",
    data_ida: negocio?.data_ida || "",
    data_volta: negocio?.data_volta || "",
    num_pessoas: negocio?.num_pessoas || 2,
    orcamento: negocio?.orcamento || "",
    tipo: negocio?.tipo || "Pacote nacional",
    motivo_viagem: negocio?.motivo_viagem || "",
    notas: negocio?.notas || "",
    motivo_perda: negocio?.motivo_perda || "",
    valor_venda: negocio?.valor_venda || "",
    custo: negocio?.custo || "",
    parcelas: negocio?.parcelas || [],
    localizador: negocio?.localizador || "",
    data_fechamento: negocio?.data_fechamento || "",
    parcelas_qtd: (negocio?.parcelas || []).length || 1,
    primeiro_venc: (negocio?.parcelas || [])[0]?.vencimento || hojeISO(),
    fornecedores: negocio?.fornecedores || [],
    ultima_mensagem: negocio?.ultima_mensagem || "",
    sinais: negocio?.sinais || {},
    perfil_manual: negocio?.perfil_manual || "",
    cruzeiro: negocio?.cruzeiro || {},
  });

  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  const setCruzeiro = (k, v) => setF((s) => ({ ...s, cruzeiro: { ...s.cruzeiro, [k]: v } }));
  const faltando = camposFaltando(f);
  const podeSalvar = f.nome.trim().length > 1;
  const eFechado = negocio?.etapa_funil === "Fechado";

  const addFornecedor = () =>
    set("fornecedores", [...f.fornecedores, { id: uid(), nome: "", tipo: "Hospedagem", status: "Solicitado" }]);

  const setFornecedor = (id, campo, valor) =>
    set("fornecedores", f.fornecedores.map((x) => (x.id === id ? { ...x, [campo]: valor } : x)));

  const rmFornecedor = (id) => set("fornecedores", f.fornecedores.filter((x) => x.id !== id));

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-900/50 p-4" onClick={onFechar}>
      <div onClick={(e) => e.stopPropagation()} className="max-h-full w-full max-w-lg overflow-y-auto rounded-2xl bg-white shadow-2xl">
        <div className="sticky top-0 flex items-center justify-between border-b border-slate-200 bg-white px-6 py-4">
          <h2 className="text-base font-semibold text-slate-900">{modo === "novo" ? "Novo lead" : "Dados do negócio"}</h2>
          <button onClick={onFechar} className="text-slate-400 hover:text-slate-600" aria-label="Fechar"><X size={18} /></button>
        </div>

        <div className="space-y-5 p-6">
          <Secao titulo="Cliente">
            <Campo label="Nome" valor={f.nome} onChange={(v) => set("nome", v)} placeholder="Nome do cliente" />
            <div className="grid grid-cols-2 gap-3">
              <Campo label="WhatsApp" valor={f.whatsapp} onChange={(v) => set("whatsapp", v)} placeholder="11 90000-0000" />
              <Seletor label="Origem" valor={f.origem} onChange={(v) => set("origem", v)} opcoes={ORIGENS} />
            </div>
            <Campo label="E-mail" valor={f.email} onChange={(v) => set("email", v)} placeholder="cliente@email.com" tipo="email" />
            {(f.origem === "Google Ads" || f.gclid) && (
              <div>
                <Campo
                  label="Código do clique (gclid)"
                  valor={f.gclid}
                  onChange={(v) => {
                    const g = extrairGclid(v) || v;
                    set("gclid", g);
                    if (g && !f.gclid_em) set("gclid_em", new Date().toISOString());
                  }}
                  placeholder="Cole a mensagem do WhatsApp ou o [ref: ...]"
                />
                <p className="mt-1 text-xs leading-relaxed text-slate-400">
                  Veio do Google Ads? Cole aqui o código que apareceu na primeira mensagem do cliente (depois de "[ref:"). É ele que, quando a venda fechar, leva a margem de volta ao Google para a campanha aprender a trazer mais clientes como este.
                </p>
              </div>
            )}
          </Secao>

          <Secao titulo="Viagem">
            <div className="grid grid-cols-2 gap-3">
              <Seletor label="Tipo" valor={f.tipo} onChange={(v) => set("tipo", v)} opcoes={TIPOS_VIAGEM} />
              <Campo label="Destino" valor={f.destino} onChange={(v) => set("destino", v)} placeholder="Ex.: Porto Seguro" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Campo label="Data de ida" valor={f.data_ida} onChange={(v) => set("data_ida", v)} tipo="date" />
              <Campo label="Data de volta" valor={f.data_volta} onChange={(v) => set("data_volta", v)} tipo="date" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <Campo label="Pessoas" valor={f.num_pessoas} onChange={(v) => set("num_pessoas", v)} tipo="number" />
              <Campo label="Orçamento (R$)" valor={f.orcamento} onChange={(v) => set("orcamento", v)} tipo="number" placeholder="0" />
            </div>
            <Campo label="Motivo da viagem" valor={f.motivo_viagem} onChange={(v) => set("motivo_viagem", v)}
              placeholder="Lua de mel, férias com os filhos, aniversário..."
              dica="O motivo é o que faz a proposta parecer feita para ele." />
          </Secao>

          {eFechado && (
            <Secao titulo="Venda e financeiro">
              <div className="grid grid-cols-3 gap-3">
                <Campo label="Valor da venda" valor={f.valor_venda} onChange={(v) => set("valor_venda", v)} tipo="number" />
                <Campo label="Custo (fornecedor)" valor={f.custo} onChange={(v) => set("custo", v)} tipo="number"
                  dica="Só sabe a comissão? Lance venda − comissão." />
                <Campo label="Localizador" valor={f.localizador} onChange={(v) => set("localizador", v)} />
              </div>

              {Number(f.valor_venda) > 0 && (
                <div className="rounded-lg bg-slate-50 p-3 text-xs">
                  <span className="text-slate-500">Margem: </span>
                  <strong className={margem(f) >= 0 ? "text-emerald-700" : "text-rose-700"}>
                    {margem(f).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
                    {Number(f.custo) > 0 && ` (${margemPercentual(f).toFixed(0)}%)`}
                  </strong>
                  <span className="ml-2 text-slate-400">
                    {Number(f.custo) > 0
                      ? "É este número que a Fase 3 envia ao Google Ads como valor da conversão."
                      : "Sem o custo, a margem fica igual à venda — e o Google Ads otimiza errado."}
                  </span>
                </div>
              )}

              <div className="rounded-lg border border-slate-200 p-3">
                <div className="mb-2 flex flex-wrap items-end gap-3">
                  <Campo label="Nº de parcelas" valor={f.parcelas_qtd} onChange={(v) => set("parcelas_qtd", v)} tipo="number" />
                  <Campo label="1º vencimento" valor={f.primeiro_venc} onChange={(v) => set("primeiro_venc", v)} tipo="date" />
                  <button
                    type="button"
                    onClick={() => set("parcelas", gerarParcelas(f.valor_venda, f.parcelas_qtd, f.primeiro_venc))}
                    className="rounded-lg bg-slate-800 px-3 py-2 text-xs font-medium text-white hover:bg-slate-700"
                  >
                    {f.parcelas.length ? "Regerar parcelas" : "Gerar parcelas"}
                  </button>
                </div>

                {f.parcelas.length > 0 ? (
                  <>
                    <div className="space-y-0.5">
                      {f.parcelas.map((p) => (
                        <div key={p.n} className="flex items-center gap-2 rounded px-1 py-1 text-xs">
                          <button
                            type="button"
                            onClick={() =>
                              set("parcelas", f.parcelas.map((x) =>
                                x.n !== p.n ? x : { ...x, pago: !x.pago, pago_em: !x.pago ? hojeISO() : null }
                              ))
                            }
                            className={`rounded px-1.5 py-0.5 font-medium ${p.pago ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}
                          >
                            {p.pago ? "paga" : "aberta"}
                          </button>
                          <span className="text-slate-500">Parcela {p.n}</span>
                          <span className="flex-1 text-slate-400">vence {p.vencimento.split("-").reverse().join("/")}</span>
                          <span className="font-semibold text-slate-700">
                            {Number(p.valor).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}
                          </span>
                        </div>
                      ))}
                    </div>
                    <p className="mt-2 text-xs text-slate-400">
                      Pagamento: <strong>{statusPagamento(f)}</strong> — calculado das parcelas, não digitado.
                    </p>
                    {divergenciaParcelas(f) !== 0 && (
                      <p className="mt-1 text-xs font-medium text-amber-700">
                        Atenção: a soma das parcelas ({totalParcelado(f).toLocaleString("pt-BR", { style: "currency", currency: "BRL" })}) não bate com o valor da venda. Enquanto não bater, o pagamento nunca chega a "Pago" e o bilhete fica travado.
                      </p>
                    )}
                  </>
                ) : (
                  <p className="text-xs text-slate-400">
                    Sem parcelas, o pagamento fica como "Pendente" e a emissão do bilhete continua travada. Gere as parcelas mesmo que seja à vista (1x).
                  </p>
                )}
              </div>

              {statusPagamento(f) !== "Pago" && (
                <div className="flex items-start gap-2 rounded-lg bg-rose-50 p-3 text-xs text-rose-700 ring-1 ring-rose-200">
                  <AlertTriangle size={14} className="mt-0.5 flex-shrink-0" />
                  Pagamento {statusPagamento(f).toLowerCase()}: não emita bilhete. Esta trava lê as parcelas sozinha.
                </div>
              )}
            </Secao>
          )}

          {eFechado && (
            <Secao titulo="Fornecedores (operação interna)">
              {f.fornecedores.length === 0 && (
                <p className="text-xs text-slate-400">Nenhum fornecedor cadastrado. Adicione hotel, aéreo, traslado, etc.</p>
              )}
              <div className="space-y-2">
                {f.fornecedores.map((fx) => {
                  const atrasado = f.data_ida && fornecedorAtrasado(fx, Math.round((new Date(f.data_ida + "T12:00:00") - Date.now()) / 864e5));
                  return (
                    <div key={fx.id} className={`flex flex-wrap items-center gap-2 rounded-lg p-3 ring-1 ${atrasado ? "bg-amber-50 ring-amber-300" : "bg-slate-50 ring-slate-200"}`}>
                      <input value={fx.nome} placeholder="Nome" onChange={(e) => setFornecedor(fx.id, "nome", e.target.value)}
                        className="flex-1 min-w-[120px] rounded border border-slate-300 px-2 py-1.5 text-sm outline-none focus:border-blue-500" />
                      <select value={fx.tipo} onChange={(e) => setFornecedor(fx.id, "tipo", e.target.value)}
                        className="rounded border border-slate-300 bg-white px-2 py-1.5 text-xs">
                        {["Hospedagem", "Aéreo", "Traslado", "Passeio", "Seguro", "Outro"].map((t) => <option key={t}>{t}</option>)}
                      </select>
                      <select value={fx.status} onChange={(e) => setFornecedor(fx.id, "status", e.target.value)}
                        className={`rounded border px-2 py-1.5 text-xs font-medium ${
                          fx.status === "Voucher recebido" ? "border-emerald-300 bg-emerald-50 text-emerald-700" :
                          fx.status === "Confirmado" ? "border-blue-300 bg-blue-50 text-blue-700" :
                          "border-amber-300 bg-amber-50 text-amber-700"
                        }`}>
                        {STATUS_FORNECEDOR.map((s) => <option key={s}>{s}</option>)}
                      </select>
                      <button onClick={() => rmFornecedor(fx.id)} className="text-slate-300 hover:text-rose-500" aria-label="Remover"><Trash2 size={14} /></button>
                      {atrasado && <span className="w-full text-xs font-medium text-amber-700">⚠ Atrasado — cobre confirmação agora</span>}
                    </div>
                  );
                })}
              </div>
              <button onClick={addFornecedor}
                className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium text-blue-600 ring-1 ring-blue-200 hover:bg-blue-50">
                <Plus size={14} /> Adicionar fornecedor
              </button>
            </Secao>
          )}

          {negocio?.etapa_funil === "Perdido" && (
            <Secao titulo="Perda">
              <Seletor label="Motivo da perda" valor={f.motivo_perda} onChange={(v) => set("motivo_perda", v)}
                opcoes={MOTIVOS_PERDA} vazio="Selecione o motivo" />
            </Secao>
          )}

          {ehCruzeiro(f) && (
            <Secao titulo="Dados do cruzeiro">
              <div className="grid grid-cols-2 gap-3">
                <Campo label="Companhia marítima" valor={f.cruzeiro.companhia} onChange={(v) => setCruzeiro("companhia", v)} placeholder="MSC, Costa..." />
                <Campo label="Roteiro / região" valor={f.cruzeiro.roteiro} onChange={(v) => setCruzeiro("roteiro", v)} placeholder="Costa Brasileira, Caribe..." />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <Campo label="Porto de embarque" valor={f.cruzeiro.porto_embarque} onChange={(v) => setCruzeiro("porto_embarque", v)} placeholder="Santos" />
                <Campo label="Noites" valor={f.cruzeiro.noites} onChange={(v) => setCruzeiro("noites", v)} tipo="number" />
                <Seletor label="Cabine" valor={f.cruzeiro.cabine || "A definir"} onChange={(v) => setCruzeiro("cabine", v)} opcoes={TIPOS_CABINE} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Seletor label="Precisa de aéreo?" valor={f.cruzeiro.com_aereo || "A definir"} onChange={(v) => setCruzeiro("com_aereo", v)} opcoes={["Sim", "Não", "A definir"]} />
                <Seletor label="Precisa de traslado?" valor={f.cruzeiro.com_traslado || "A definir"} onChange={(v) => setCruzeiro("com_traslado", v)} opcoes={["Sim", "Não", "A definir"]} />
              </div>
              <p className="text-xs leading-relaxed text-slate-400">
                O checklist do que precisa ser explicado ao cliente (taxas, gorjetas, bebidas, cabine, cancelamento) fica na tela Agora.
              </p>
            </Secao>
          )}

          <Secao titulo="Última fala do cliente">
            <AreaTexto
              valor={f.ultima_mensagem}
              onChange={(v) => set("ultima_mensagem", v)}
              placeholder="Cole aqui a última mensagem dele, na íntegra."
              linhas={2}
            />
            <p className="text-xs leading-relaxed text-slate-400">
              Serve para você reler antes de responder. Os sinais que alimentam a análise você marca na tela Agora, durante a conversa.
            </p>
          </Secao>

          <Secao titulo="Anotações">
            <AreaTexto valor={f.notas} onChange={(v) => set("notas", v)} placeholder="O que o cliente falou, preferências, restrições..." />
          </Secao>

          {faltando.length > 0 && (
            <div className="flex items-start gap-2 rounded-lg bg-amber-50 p-3 text-xs leading-snug text-amber-800 ring-1 ring-amber-200">
              <Lock size={14} className="mt-0.5 flex-shrink-0" />
              <span>Faltam <strong>{faltando.join(", ")}</strong> para liberar a etapa "Montando Proposta".</span>
            </div>
          )}
        </div>

        <div className="sticky bottom-0 flex items-center gap-3 border-t border-slate-200 bg-white px-6 py-4">
          {modo === "editar" && (
            <button onClick={() => onExcluir(f.id)}
              className="rounded-lg px-3 py-2 text-sm font-medium text-slate-400 transition hover:bg-rose-50 hover:text-rose-600">Excluir</button>
          )}
          <button onClick={onFechar} className="ml-auto rounded-lg px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100">Cancelar</button>
          <button disabled={!podeSalvar} onClick={() => onSalvar(f)}
            className="rounded-lg bg-blue-600 px-5 py-2 text-sm font-medium text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:bg-slate-300">Salvar</button>
        </div>
      </div>
    </div>
  );
}
