import React, { useState } from "react";
import {
  Thermometer, Target, Copy, MessageCircle, ShieldAlert, TrendingUp,
  ChevronDown, ChevronUp, Ship, CheckCircle2, Circle, Zap, AlertTriangle,
  Send, MessagesSquare, Clock, Plus, Sparkles,
} from "lucide-react";
import { analisar, SINAIS, GRUPOS_SINAIS, COR_TEMPERATURA, PERFIS } from "../lib/atendimento.js";
import { analisarCruzeiro, ehCruzeiro, CHECKLIST_CRUZEIRO } from "../lib/cruzeiro.js";
import { janela24h, sinaisSugeridos, resumoConversa, saudacaoInicial, DIRECAO } from "../lib/whatsapp.js";
import { slaHoras } from "../lib/motor.js";
import { primeiroNome } from "../lib/dominio.js";

const linkWhats = (numero, texto) => {
  const d = String(numero || "").replace(/\D/g, "");
  const completo = d.startsWith("55") ? d : `55${d}`;
  return `https://wa.me/${completo}?text=${encodeURIComponent(texto)}`;
};

export default function PainelAtendimento({ negocio, cliente, acoes, toast }) {
  const [aberto, setAberto] = useState(true);
  const [editandoSinais, setEditandoSinais] = useState(false);

  const a = analisar(negocio, cliente, slaHoras(negocio));
  const cr = analisarCruzeiro(negocio);
  const cor = COR_TEMPERATURA[a.temperatura.faixa];

  const copiar = (texto) => {
    navigator.clipboard?.writeText(texto);
    toast("Mensagem copiada.", "ok");
  };

  return (
    <div className="mt-5 overflow-hidden rounded-xl border border-slate-200">
      {/* Cabeçalho: temperatura + nota + risco */}
      <button
        onClick={() => setAberto((v) => !v)}
        className={`flex w-full flex-wrap items-center gap-3 px-4 py-3 text-left ${cor.fundo}`}
      >
        <span className={`flex h-7 w-7 items-center justify-center rounded-full ${cor.ponto}`}>
          <Thermometer size={14} className="text-white" />
        </span>
        <div className="flex-1">
          <p className={`text-sm font-semibold ${cor.texto}`}>
            Lead {a.temperatura.faixa} · nota {a.temperatura.nota}/10
          </p>
          <p className="text-xs text-slate-500">
            {a.perfil ? a.perfil.titulo : "Perfil ainda indefinido"}
            {a.perfisSecundarios.length > 0 && ` + ${a.perfisSecundarios.map((p) => p.titulo).join(", ")}`}
          </p>
        </div>
        <span
          className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
            a.risco.nivel === "Alto"
              ? "bg-rose-600 text-white"
              : a.risco.nivel === "Médio"
              ? "bg-amber-500 text-white"
              : "bg-emerald-600 text-white"
          }`}
        >
          Risco {a.risco.nivel}
        </span>
        {aberto ? <ChevronUp size={16} className="text-slate-400" /> : <ChevronDown size={16} className="text-slate-400" />}
      </button>

      {aberto && (
        <div className="space-y-4 bg-white p-4">
          {/* Fase 4: a conversa real do WhatsApp, dentro do card */}
          <BlocoConversa negocio={negocio} cliente={cliente} acoes={acoes} toast={toast} onCopiar={copiar} />

          {/* Última mensagem do cliente */}
          {negocio.ultima_mensagem && (
            <div className="rounded-lg bg-slate-50 p-3">
              <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-slate-400">Última fala dele</p>
              <p className="text-sm italic leading-relaxed text-slate-600">"{negocio.ultima_mensagem}"</p>
            </div>
          )}

          {/* Por que essa nota */}
          {a.temperatura.sinais.length > 0 && (
            <div>
              <p className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-slate-400">Por que essa nota</p>
              <div className="flex flex-wrap gap-1.5">
                {a.temperatura.sinais.map((s) => (
                  <span key={s} className="rounded-md bg-slate-100 px-2 py-0.5 text-xs text-slate-600">
                    {s}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Risco */}
          {a.risco.motivos.length > 0 && (
            <div className="flex items-start gap-2 rounded-lg bg-rose-50 p-3 text-xs leading-relaxed text-rose-800 ring-1 ring-rose-100">
              <TrendingUp size={14} className="mt-0.5 flex-shrink-0" />
              <span>
                <strong>Risco {a.risco.nivel}:</strong> {a.risco.motivos.join("; ")}.
              </span>
            </div>
          )}

          {/* Próxima ação + tom */}
          <div className="rounded-lg bg-blue-50 p-3 ring-1 ring-blue-100">
            <p className="mb-1 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-blue-700">
              <Target size={12} /> Próxima ação
            </p>
            <p className="text-sm leading-relaxed text-blue-900">{a.proximaAcao}</p>
            <p className="mt-2 text-xs text-blue-700">
              <strong>Tom:</strong> {a.tom}
            </p>
          </div>

          {/* Alertas de conformidade — o que NÃO dizer */}
          {a.alertas.length > 0 && (
            <div className="rounded-lg bg-amber-50 p-3 ring-1 ring-amber-200">
              <p className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-amber-800">
                <ShieldAlert size={12} /> O que você não pode dizer
              </p>
              <ul className="space-y-1">
                {a.alertas.map((x, i) => (
                  <li key={i} className="flex items-start gap-1.5 text-xs leading-relaxed text-amber-900">
                    <span className="mt-1.5 h-1 w-1 flex-shrink-0 rounded-full bg-amber-600" />
                    {x}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Gatilhos */}
          {a.gatilhos.length > 0 && (
            <div>
              <p className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-slate-400">
                <Zap size={12} /> Gatilhos para este cliente
              </p>
              <div className="space-y-1.5">
                {a.gatilhos.map((g) => (
                  <Gatilho key={g.id} g={g} onCopiar={copiar} />
                ))}
              </div>
            </div>
          )}

          {/* Frases prontas do perfil */}
          {a.frases && (
            <div>
              <p className="mb-1.5 text-xs font-semibold uppercase tracking-wider text-slate-400">
                Frases prontas — {a.perfil.titulo}
              </p>
              <div className="space-y-2">
                {a.frases.abertura && <Frase rotulo="Abertura" texto={a.frases.abertura} whats={cliente?.whatsapp} onCopiar={copiar} />}
                {a.curta && <Frase rotulo="Versão curta" texto={a.curta} whats={cliente?.whatsapp} onCopiar={copiar} />}
                {a.frases.extra && <Frase rotulo="Reforço" texto={a.frases.extra} whats={cliente?.whatsapp} onCopiar={copiar} />}
                {a.frases.pergunta && <Frase rotulo="Pergunta estratégica" texto={a.frases.pergunta} whats={cliente?.whatsapp} onCopiar={copiar} destaque />}
                {a.frases.fechamento && <Frase rotulo="Fechamento" texto={a.frases.fechamento} whats={cliente?.whatsapp} onCopiar={copiar} />}
              </div>
            </div>
          )}

          {/* Bloco de cruzeiro */}
          {cr && <BlocoCruzeiro cr={cr} negocio={negocio} cliente={cliente} acoes={acoes} onCopiar={copiar} />}

          {/* Sinais */}
          <div className="border-t border-slate-100 pt-3">
            <button
              onClick={() => setEditandoSinais((v) => !v)}
              className="flex w-full items-center justify-between text-xs font-semibold uppercase tracking-wider text-slate-400 hover:text-slate-600"
            >
              <span>O que ele te disse ({Object.values(negocio.sinais || {}).filter(Boolean).length} marcados)</span>
              {editandoSinais ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>
            <p className="mt-1 text-xs text-slate-400">
              A análise acima muda conforme você marca. Marque durante a conversa, não depois.
            </p>

            {editandoSinais && (
              <div className="mt-3 space-y-3">
                {GRUPOS_SINAIS.map((grupo) => {
                  const doGrupo = SINAIS.filter((s) => s.grupo === grupo);
                  if (grupo === "Cruzeiro" && !ehCruzeiro(negocio)) return null;
                  return (
                    <div key={grupo}>
                      <p className="mb-1 text-xs font-medium text-slate-500">{grupo}</p>
                      <div className="flex flex-wrap gap-1.5">
                        {doGrupo.map((s) => {
                          const ativo = Boolean(negocio.sinais?.[s.id]);
                          return (
                            <button
                              key={s.id}
                              onClick={() => acoes.marcarSinal(negocio.id, s.id, !ativo)}
                              className={`rounded-lg px-2.5 py-1 text-xs transition ${
                                ativo
                                  ? "bg-slate-800 font-medium text-white"
                                  : "bg-white text-slate-500 ring-1 ring-slate-200 hover:bg-slate-50"
                              }`}
                            >
                              {s.texto}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}

                <div>
                  <p className="mb-1 text-xs font-medium text-slate-500">Forçar um perfil (ignora a detecção)</p>
                  <select
                    value={negocio.perfil_manual || ""}
                    onChange={(e) => acoes.definirPerfil(negocio.id, e.target.value)}
                    className="w-full rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-xs"
                  >
                    <option value="">Detecção automática</option>
                    {Object.entries(PERFIS).map(([id, p]) => (
                      <option key={id} value={id}>
                        {p.titulo}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------- auxiliares ---------------- */

function Gatilho({ g, onCopiar }) {
  const [aberto, setAberto] = useState(false);
  return (
    <div className={`rounded-lg ring-1 ${g.cuidado ? "bg-amber-50 ring-amber-200" : "bg-slate-50 ring-slate-200"}`}>
      <button onClick={() => setAberto((v) => !v)} className="flex w-full items-center gap-2 px-3 py-2 text-left">
        <span className={`text-xs font-semibold ${g.cuidado ? "text-amber-800" : "text-slate-700"}`}>{g.titulo}</span>
        <span className="flex-1 truncate text-xs text-slate-400">{g.quando}</span>
        {aberto ? <ChevronUp size={13} className="text-slate-400" /> : <ChevronDown size={13} className="text-slate-400" />}
      </button>
      {aberto && (
        <div className="px-3 pb-3">
          <p className="text-sm leading-relaxed text-slate-700">{g.frase}</p>
          {g.cuidado && (
            <p className="mt-2 flex items-start gap-1.5 text-xs font-medium leading-relaxed text-amber-800">
              <AlertTriangle size={12} className="mt-0.5 flex-shrink-0" /> {g.cuidado}
            </p>
          )}
          <button
            onClick={() => onCopiar(g.frase)}
            className="mt-2 flex items-center gap-1 text-xs font-medium text-blue-600 hover:text-blue-800"
          >
            <Copy size={11} /> Copiar
          </button>
        </div>
      )}
    </div>
  );
}

function Frase({ rotulo, texto, whats, onCopiar, destaque }) {
  return (
    <div className={`rounded-lg p-3 ring-1 ${destaque ? "bg-emerald-50 ring-emerald-200" : "bg-white ring-slate-200"}`}>
      <p className={`mb-1 text-xs font-semibold ${destaque ? "text-emerald-700" : "text-slate-400"}`}>{rotulo}</p>
      <p className="text-sm leading-relaxed text-slate-700">{texto}</p>
      <div className="mt-2 flex gap-3">
        {whats && (
          <a
            href={linkWhats(whats, texto)}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1 text-xs font-medium text-emerald-700 hover:text-emerald-900"
          >
            <MessageCircle size={11} /> Enviar
          </a>
        )}
        <button onClick={() => onCopiar(texto)} className="flex items-center gap-1 text-xs font-medium text-blue-600 hover:text-blue-800">
          <Copy size={11} /> Copiar
        </button>
      </div>
    </div>
  );
}

function BlocoCruzeiro({ cr, negocio, cliente, acoes, onCopiar }) {
  const [aberto, setAberto] = useState(true);
  const feitos = negocio.checklist_cruzeiro || {};

  return (
    <div className="rounded-lg bg-indigo-50 p-3 ring-1 ring-indigo-200">
      <button onClick={() => setAberto((v) => !v)} className="flex w-full items-center gap-2 text-left">
        <Ship size={14} className="text-indigo-700" />
        <span className="flex-1 text-xs font-semibold uppercase tracking-wider text-indigo-800">
          Cruzeiro · {cr.perfil?.titulo}
        </span>
        {cr.criticos.length > 0 && (
          <span className="rounded-full bg-rose-600 px-2 py-0.5 text-xs font-semibold text-white">
            {cr.criticos.length} crítico{cr.criticos.length > 1 ? "s" : ""}
          </span>
        )}
        {aberto ? <ChevronUp size={14} className="text-indigo-400" /> : <ChevronDown size={14} className="text-indigo-400" />}
      </button>

      {aberto && (
        <div className="mt-3 space-y-3">
          {cr.perfil?.alerta && (
            <p className="flex items-start gap-1.5 rounded-md bg-amber-100 p-2 text-xs font-medium leading-relaxed text-amber-900">
              <AlertTriangle size={12} className="mt-0.5 flex-shrink-0" /> {cr.perfil.alerta}
            </p>
          )}

          {cr.perfil?.abertura && (
            <Frase rotulo="Abertura para este perfil" texto={cr.perfil.abertura} whats={cliente?.whatsapp} onCopiar={onCopiar} />
          )}
          {cr.perfil?.pergunta && (
            <Frase rotulo="Pergunta estratégica" texto={cr.perfil.pergunta} whats={cliente?.whatsapp} onCopiar={onCopiar} destaque />
          )}

          {cr.dadosFaltando.length > 0 && (
            <p className="text-xs leading-relaxed text-indigo-800">
              <strong>Ainda não sei:</strong> {cr.dadosFaltando.join(", ")}.
            </p>
          )}

          <div>
            <p className="mb-1.5 text-xs font-semibold text-indigo-800">
              Precisa estar explicado antes de fechar ({CHECKLIST_CRUZEIRO.length - cr.pendentes.length}/{CHECKLIST_CRUZEIRO.length})
            </p>
            <p className="mb-2 text-xs leading-relaxed text-indigo-700">
              Taxa, gorjeta e bebida não explicadas viram reclamação a bordo — e avaliação ruim depois.
            </p>
            <div className="space-y-0.5">
              {CHECKLIST_CRUZEIRO.map((i) => {
                const ok = Boolean(feitos[i.id]);
                return (
                  <button
                    key={i.id}
                    onClick={() => acoes.marcarCruzeiro(negocio.id, i.id, !ok)}
                    className="flex w-full items-center gap-2 rounded px-1.5 py-1 text-left hover:bg-white/60"
                  >
                    {ok ? (
                      <CheckCircle2 size={14} className="flex-shrink-0 text-emerald-600" />
                    ) : (
                      <Circle size={14} className={`flex-shrink-0 ${i.critico ? "text-rose-400" : "text-slate-300"}`} />
                    )}
                    <span className={`flex-1 text-xs ${ok ? "text-slate-400 line-through" : "text-slate-700"}`}>{i.texto}</span>
                    {i.critico && !ok && <span className="text-xs font-medium text-rose-500">crítico</span>}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}


/* ============================================================
   FASE 4 — A CONVERSA DENTRO DO CARD

   Traz o histórico real do WhatsApp para o negócio e transforma o
   que o cliente escreveu em SUGESTÕES de sinais (nunca em marcação
   automática). Enquanto a Cloud API da Meta não está ligada, roda em
   "modo ensaio": o simulador deixa você lançar a mensagem recebida à
   mão e ver todo o fluxo — igual ao modo ensaio do Google Ads.
   ============================================================ */
const linkWhatsConversa = (numero, texto) => {
  const d = String(numero || "").replace(/\D/g, "");
  const completo = d.startsWith("55") ? d : `55${d}`;
  return `https://wa.me/${completo}?text=${encodeURIComponent(texto)}`;
};

function BlocoConversa({ negocio, cliente, acoes, toast, onCopiar }) {
  const [aberto, setAberto] = useState(true);
  const [texto, setTexto] = useState("");
  const [recebida, setRecebida] = useState("");
  const [simularAberto, setSimularAberto] = useState(false);

  const fio = negocio.conversa || [];
  const resumo = resumoConversa(negocio);
  const janela = janela24h(negocio);
  const sugestoes = sinaisSugeridos(negocio);

  const enviar = () => {
    const t = texto.trim();
    if (!t) return;
    acoes.enviarMensagem(negocio.id, t);
    // No modo ensaio, o envio de verdade é o WhatsApp abrindo com o texto.
    if (cliente?.whatsapp) window.open(linkWhatsConversa(cliente.whatsapp, t), "_blank", "noopener");
    setTexto("");
    toast("Mensagem registrada no fio. O WhatsApp abriu para o envio.", "ok");
  };

  const receber = () => {
    const t = recebida.trim();
    if (!t) return;
    acoes.registrarMensagemCliente(negocio.id, t);
    setRecebida("");
    toast("Mensagem do cliente registrada. Confira os sinais sugeridos abaixo.", "ia");
  };

  return (
    <div className="overflow-hidden rounded-xl border border-emerald-200">
      <button
        onClick={() => setAberto((v) => !v)}
        className="flex w-full items-center gap-2 bg-emerald-50 px-4 py-2.5 text-left"
      >
        <MessagesSquare size={15} className="text-emerald-700" />
        <span className="flex-1 text-xs font-semibold uppercase tracking-wider text-emerald-800">
          Conversa {resumo.total > 0 && `· ${resumo.total} mensage${resumo.total > 1 ? "ns" : "m"}`}
        </span>
        {janela.precisaTemplate ? (
          <span className="rounded-full bg-amber-500 px-2 py-0.5 text-[11px] font-semibold text-white">Fora das 24h</span>
        ) : (
          <span className="rounded-full bg-emerald-600 px-2 py-0.5 text-[11px] font-semibold text-white">
            ~{janela.horasRestantes}h de janela
          </span>
        )}
        {aberto ? <ChevronUp size={15} className="text-emerald-400" /> : <ChevronDown size={15} className="text-emerald-400" />}
      </button>

      {aberto && (
        <div className="space-y-3 bg-white p-3">
          {/* Fio de mensagens */}
          {fio.length > 0 ? (
            <div className="max-h-64 space-y-1.5 overflow-y-auto rounded-lg bg-slate-50 p-2.5">
              {fio.map((m) => (
                <Bolha key={m.id} m={m} />
              ))}
            </div>
          ) : (
            <p className="rounded-lg bg-slate-50 p-3 text-center text-xs text-slate-400">
              Sem conversa registrada ainda. Use o simulador abaixo para lançar a mensagem que o cliente enviou.
            </p>
          )}

          {/* Sinais sugeridos a partir do texto — você confirma */}
          {sugestoes.length > 0 && (
            <div className="rounded-lg bg-sky-50 p-3 ring-1 ring-sky-200">
              <p className="mb-1.5 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-sky-800">
                <Sparkles size={12} /> Detectei no que ele escreveu
              </p>
              <p className="mb-2 text-xs leading-relaxed text-sky-700">
                Confirme só o que fizer sentido. Nada muda a temperatura até você tocar — o CRM não adivinha por você.
              </p>
              <div className="flex flex-wrap gap-1.5">
                {sugestoes.map((sg) => (
                  <button
                    key={sg.id}
                    onClick={() => {
                      acoes.marcarSinal(negocio.id, sg.id, true);
                      toast(`Sinal "${sg.motivo}" confirmado.`, "ok");
                    }}
                    title={`Trecho: "${sg.trecho}"`}
                    className="flex items-center gap-1 rounded-lg bg-white px-2.5 py-1 text-xs font-medium text-sky-800 ring-1 ring-sky-300 transition hover:bg-sky-100"
                  >
                    <Plus size={11} /> {sg.motivo}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Aviso de janela de 24h */}
          <div
            className={`flex items-start gap-2 rounded-lg p-2.5 text-xs leading-relaxed ring-1 ${
              janela.precisaTemplate ? "bg-amber-50 text-amber-900 ring-amber-200" : "bg-slate-50 text-slate-500 ring-slate-200"
            }`}
          >
            <Clock size={13} className="mt-0.5 flex-shrink-0" />
            <span>{janela.motivo}</span>
          </div>

          {/* Caixa de resposta */}
          <div>
            <textarea
              value={texto}
              onChange={(e) => setTexto(e.target.value)}
              placeholder="Escreva sua resposta..."
              rows={2}
              className="w-full resize-y rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-700 focus:border-emerald-400 focus:outline-none"
            />
            <div className="mt-1.5 flex items-center gap-2">
              <button
                onClick={enviar}
                disabled={!texto.trim()}
                className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 text-xs font-medium text-white transition hover:bg-emerald-700 disabled:cursor-not-allowed disabled:bg-slate-300"
              >
                <Send size={12} /> Enviar pelo WhatsApp
              </button>
              <button
                onClick={() => setTexto(saudacaoInicial(cliente))}
                className="rounded-lg px-2 py-2 text-xs font-medium text-slate-500 transition hover:bg-slate-100"
              >
                Usar saudação
              </button>
              {texto.trim() && (
                <button
                  onClick={() => onCopiar(texto)}
                  className="flex items-center gap-1 text-xs font-medium text-blue-600 hover:text-blue-800"
                >
                  <Copy size={11} /> Copiar
                </button>
              )}
            </div>
          </div>

          {/* Simulador de mensagem recebida (modo ensaio) */}
          <div className="border-t border-slate-100 pt-2.5">
            <button
              onClick={() => setSimularAberto((v) => !v)}
              className="flex w-full items-center justify-between text-xs font-semibold uppercase tracking-wider text-slate-400 hover:text-slate-600"
            >
              <span>Simular mensagem recebida (modo ensaio)</span>
              {simularAberto ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
            </button>
            {simularAberto && (
              <div className="mt-2">
                <p className="mb-1.5 text-xs leading-relaxed text-slate-400">
                  Cole aqui o que o cliente te escreveu no WhatsApp. Ela entra no fio e vira sugestão de sinais — do mesmo
                  jeito que a Cloud API da Meta fará quando estiver ligada.
                </p>
                <textarea
                  value={recebida}
                  onChange={(e) => setRecebida(e.target.value)}
                  placeholder='Ex.: "Quanto custa? É a nossa primeira viagem internacional."'
                  rows={2}
                  className="w-full resize-y rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-700 focus:border-sky-400 focus:outline-none"
                />
                <button
                  onClick={receber}
                  disabled={!recebida.trim()}
                  className="mt-1.5 flex items-center gap-1.5 rounded-lg bg-slate-800 px-3 py-2 text-xs font-medium text-white transition hover:bg-slate-900 disabled:cursor-not-allowed disabled:bg-slate-300"
                >
                  <Plus size={12} /> Registrar como recebida
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function Bolha({ m }) {
  const saida = m.direcao === DIRECAO.SAIDA;
  const hora = (() => {
    try {
      return new Date(m.ts).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
    } catch {
      return "";
    }
  })();
  return (
    <div className={`flex ${saida ? "justify-end" : "justify-start"}`}>
      <div
        className={`max-w-[85%] rounded-2xl px-3 py-1.5 text-sm leading-relaxed ${
          saida ? "rounded-br-sm bg-emerald-600 text-white" : "rounded-bl-sm bg-white text-slate-700 ring-1 ring-slate-200"
        }`}
      >
        <p>{m.texto}</p>
        <p className={`mt-0.5 text-[10px] ${saida ? "text-emerald-100" : "text-slate-400"}`}>
          {saida ? "Você" : "Cliente"} · {hora}
        </p>
      </div>
    </div>
  );
}
