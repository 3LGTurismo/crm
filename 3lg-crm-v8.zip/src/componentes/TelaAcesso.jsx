import React, { useState } from "react";
import { Lock, LogIn, ShieldCheck, Eye, EyeOff } from "lucide-react";
import { definirAcesso, verificarAcesso, validarNovaSenha } from "../lib/acesso.js";

/* ============================================================
   TELA DE ACESSO — a porta de entrada.

   Dois modos:
   - "criar": primeiro acesso. Você define login e senha. Nada vem
     embutido; a credencial nasce aqui.
   - "entrar": já existe credencial. Confere login + senha.

   A verificação é assíncrona (PBKDF2 leva alguns milissegundos de
   propósito — é o que deixa a adivinhação lenta).
   ============================================================ */
export default function TelaAcesso({ modo, acesso, onCriar, onEntrar }) {
  const criando = modo === "criar";
  const [login, setLogin] = useState("");
  const [senha, setSenha] = useState("");
  const [repetir, setRepetir] = useState("");
  const [erro, setErro] = useState("");
  const [ocupado, setOcupado] = useState(false);
  const [verSenha, setVerSenha] = useState(false);

  const enviar = async (e) => {
    e.preventDefault();
    setErro("");

    if (criando) {
      const problema = validarNovaSenha(login, senha, repetir);
      if (problema) return setErro(problema);
      setOcupado(true);
      const cred = await definirAcesso(login, senha);
      setOcupado(false);
      onCriar(cred);
      return;
    }

    setOcupado(true);
    const ok = await verificarAcesso(acesso, login, senha);
    setOcupado(false);
    if (ok) onEntrar();
    else setErro("Login ou senha incorretos.");
  };

  return (
    <div className="flex h-screen w-full items-center justify-center bg-slate-900 p-4">
      <form onSubmit={enviar} className="w-full max-w-sm rounded-2xl bg-white p-7 shadow-xl">
        <div className="mb-5 flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-600 font-bold text-white">3</div>
          <div>
            <p className="text-sm font-semibold text-slate-900">3LG TURISMO</p>
            <p className="text-xs text-slate-500">CRM do Leonardo</p>
          </div>
        </div>

        <div className="mb-4 flex items-center gap-2 text-slate-700">
          {criando ? <ShieldCheck size={18} className="text-blue-600" /> : <Lock size={18} className="text-blue-600" />}
          <h1 className="text-base font-semibold">{criando ? "Criar acesso" : "Entrar"}</h1>
        </div>

        {criando && (
          <p className="mb-4 rounded-lg bg-blue-50 p-3 text-xs leading-relaxed text-blue-800 ring-1 ring-blue-100">
            Este é o primeiro acesso. Defina um login e uma senha — eles ficam só com você e não são enviados a lugar
            nenhum. Anote em local seguro: sem eles não há como recuperar (não guardamos a senha, só uma marca dela).
          </p>
        )}

        <label className="mb-1 block text-xs font-medium text-slate-500">Login</label>
        <input
          value={login}
          onChange={(e) => setLogin(e.target.value)}
          autoFocus
          autoComplete="username"
          className="mb-3 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-400 focus:outline-none"
          placeholder="ex.: leonardo"
        />

        <label className="mb-1 block text-xs font-medium text-slate-500">Senha</label>
        <div className="relative mb-3">
          <input
            type={verSenha ? "text" : "password"}
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            autoComplete={criando ? "new-password" : "current-password"}
            className="w-full rounded-lg border border-slate-300 px-3 py-2 pr-10 text-sm focus:border-blue-400 focus:outline-none"
            placeholder={criando ? "ao menos 6 caracteres" : "sua senha"}
          />
          <button
            type="button"
            onClick={() => setVerSenha((v) => !v)}
            className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            tabIndex={-1}
          >
            {verSenha ? <EyeOff size={16} /> : <Eye size={16} />}
          </button>
        </div>

        {criando && (
          <>
            <label className="mb-1 block text-xs font-medium text-slate-500">Repita a senha</label>
            <input
              type={verSenha ? "text" : "password"}
              value={repetir}
              onChange={(e) => setRepetir(e.target.value)}
              autoComplete="new-password"
              className="mb-3 w-full rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-400 focus:outline-none"
              placeholder="a mesma senha"
            />
          </>
        )}

        {erro && <p className="mb-3 rounded-lg bg-rose-50 p-2.5 text-xs font-medium text-rose-700 ring-1 ring-rose-100">{erro}</p>}

        <button
          type="submit"
          disabled={ocupado}
          className="flex w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-medium text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:bg-slate-300"
        >
          {criando ? <ShieldCheck size={16} /> : <LogIn size={16} />}
          {ocupado ? "Aguarde..." : criando ? "Criar acesso e entrar" : "Entrar"}
        </button>

        <p className="mt-4 text-center text-[11px] leading-relaxed text-slate-400">
          Tranca local do navegador. Protege o acesso casual à página. Para segurança de servidor, o próximo passo é o
          Supabase Auth (veja o README).
        </p>
      </form>
    </div>
  );
}
