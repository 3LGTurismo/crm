import React, { useState, useEffect, useRef, useCallback } from "react";
import { Zap, LayoutGrid, CheckSquare, Bot, Plus, RefreshCw, Wallet, Lock } from "lucide-react";

import { ETAPAS, ROTEIRO, agora, uid, hojeISO, horasAtras, horasDesde, qualificacaoCompleta } from "./lib/dominio.js";
import { rodarAgentes, agenteFechamento, resumoDoDia } from "./lib/motor.js";
import { carregarEstado, salvarEstado, exportarBackup, importarBackup } from "./lib/persistencia.js";
import { dadosIniciais } from "./lib/dadosIniciais.js";
import { gerarParcelas, resumoFinanceiro } from "./lib/financeiro.js";
import { montarConversao, statusConversao, STATUS_CONVERSAO } from "./lib/conversao.js";
import { temAcesso } from "./lib/acesso.js";
import { novaMensagem, anexarMensagem, DIRECAO } from "./lib/whatsapp.js";

/* Estado salvo antes do módulo financeiro não tem parcelas nem custo.
   Sem isto, quem já usava o CRM abriria o app com o dinheiro zerado. */
function migrar(estado) {
  if (!estado?.negocios) return estado;
  let mudou = false;
  const negocios = estado.negocios.map((n) => {
    if (n.parcelas && n.custo !== undefined) return n;
    mudou = true;
    const novo = { ...n };
    if (novo.custo === undefined) {
      // comissão antiga vira custo: custo = venda - comissão
      novo.custo = Number(n.valor_venda) && Number(n.comissao) ? Number(n.valor_venda) - Number(n.comissao) : 0;
    }
    if (!novo.parcelas) {
      novo.parcelas = Number(n.valor_venda) ? gerarParcelas(n.valor_venda, 1, hojeISO()) : [];
      // respeita o status que ele tinha digitado antes
      if (n.status_pagamento === "Pago") novo.parcelas = novo.parcelas.map((p) => ({ ...p, pago: true, pago_em: hojeISO() }));
    }
    if (!novo.data_fechamento && n.etapa_funil === "Fechado") novo.data_fechamento = hojeISO();
    if (!novo.sinais) novo.sinais = {};
    if (!novo.checklist_cruzeiro) novo.checklist_cruzeiro = {};
    if (!novo.conversao) novo.conversao = {};
    delete novo.comissao;
    delete novo.status_pagamento;
    return novo;
  });
  const clientes = (estado.clientes || []).map((c) =>
    c.gclid === undefined ? { ...c, gclid: null, gclid_em: null } : c
  );
  const agentes = { operacoes: true, ...(estado.agentes || {}) };
  if (clientes.some((c, i) => c !== estado.clientes[i])) mudou = true;
  return mudou || !estado.agentes?.operacoes ? { ...estado, negocios, clientes, agentes } : estado;
}

import Agora from "./telas/Agora.jsx";
import Funil from "./telas/Funil.jsx";
import Tarefas from "./telas/Tarefas.jsx";
import ComandoIA from "./telas/ComandoIA.jsx";
import Dinheiro from "./telas/Dinheiro.jsx";
import ModalNegocio from "./componentes/ModalNegocio.jsx";
import TelaAcesso from "./componentes/TelaAcesso.jsx";
import { Toasts } from "./componentes/ui.jsx";

export default function App() {
  const [estado, setEstado] = useState(null);
  const [tela, setTela] = useState("agora");
  const [toasts, setToasts] = useState([]);
  const [modal, setModal] = useState(null);
  const [desbloqueado, setDesbloqueado] = useState(() => {
    try { return sessionStorage.getItem("crm3lg:sessao") === "1"; } catch { return false; }
  });
  const ref = useRef(null);
  ref.current = estado;

  useEffect(() => {
    let vivo = true;
    carregarEstado().then((s) => vivo && setEstado(migrar(s) || dadosIniciais()));
    return () => {
      vivo = false;
    };
  }, []);

  useEffect(() => {
    if (estado) salvarEstado(estado);
  }, [estado]);

  const abrirSessao = useCallback(() => {
    try { sessionStorage.setItem("crm3lg:sessao", "1"); } catch {}
    setDesbloqueado(true);
  }, []);

  const toast = useCallback((msg, tipo = "ok") => {
    const id = uid();
    setToasts((t) => [...t, { id, msg, tipo }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 6000);
  }, []);

  const clienteDe = (id) => estado?.clientes.find((c) => c.id === id);

  const log = (st, nome_agente, acao_realizada) => ({
    ...st,
    logs: [{ id: uid(), nome_agente, acao_realizada, timestamp: agora() }, ...st.logs].slice(0, 300),
  });

  const patch = (st, id, mudanca) => ({
    ...st,
    negocios: st.negocios.map((n) => (n.id === id ? { ...n, ...mudanca } : n)),
  });

  /* ---------------- agentes ---------------- */

  const verificar = useCallback(
    (silencioso = true) => {
      setEstado((st) => {
        if (!st) return st;
        const { tarefas, logs } = rodarAgentes(st);
        if (tarefas.length === 0) {
          if (!silencioso) setTimeout(() => toast("Tudo dentro do prazo. Nenhum alerta novo.", "ok"), 0);
          return st;
        }
        if (!silencioso || tarefas.length > 0) {
          setTimeout(
            () => toast(`Os agentes criaram ${tarefas.length} ${tarefas.length === 1 ? "alerta" : "alertas"}.`, "ia"),
            0
          );
        }
        return { ...st, tarefas: [...tarefas, ...st.tarefas], logs: [...logs.reverse(), ...st.logs].slice(0, 300) };
      });
    },
    [toast]
  );

  useEffect(() => {
    if (!estado) return;
    const t = setInterval(() => verificar(true), 20000);
    return () => clearInterval(t);
  }, [estado, verificar]);

  useEffect(() => {
    if (!estado) return;
    const t = setTimeout(() => verificar(true), 800);
    return () => clearTimeout(t);
  }, [estado === null]); // eslint-disable-line react-hooks/exhaustive-deps

  /* ---------------- ações ---------------- */

  const moverNegocio = (id, etapa) => {
    const st = ref.current;
    const n = st.negocios.find((x) => x.id === id);
    if (!n || n.etapa_funil === etapa) return;

    if (etapa === "Montando Proposta" && !qualificacaoCompleta(n)) {
      toast("Atenção: Faça a qualificação completa (Destino, Datas e Orçamento) antes de montar/enviar a proposta.", "erro");
      return;
    }

    setEstado((s) => {
      // A data de fechamento é o que faz a margem entrar no mês certo.
      const extra = etapa === "Fechado" && !n.data_fechamento ? { data_fechamento: hojeISO() } : {};
      let novo = patch(s, id, { etapa_funil: etapa, ultima_interacao: agora(), adiado_ate: null, ...extra });
      const c = s.clientes.find((x) => x.id === n.cliente_id);
      novo = log(novo, "Sistema", `${c?.nome || "Cliente"} entrou em "${etapa}".`);

      if (etapa === "Negociação" && s.agentes.vendas) {
        const r = agenteFechamento(novo, { ...n, etapa_funil: etapa });
        if (r) {
          novo = { ...novo, tarefas: [r.tarefa, ...novo.tarefas], logs: [r.log, ...novo.logs] };
          setTimeout(() => toast("Script de fechamento pronto em Tarefas do dia.", "ia"), 0);
        }
      }
      return novo;
    });

    if (etapa === "Perdido" || etapa === "Fechado") {
      const atual = ref.current.negocios.find((x) => x.id === id);
      setTimeout(() => setModal({ modo: "editar", negocio: { ...atual, etapa_funil: etapa } }), 100);
    }
  };

  const acoes = {
    novoLead: () => setModal({ modo: "novo" }),
    abrirEdicao: (n) => setModal({ modo: "editar", negocio: n }),

    marcarPasso: (id, passoId, valor) =>
      setEstado((s) => {
        const n = s.negocios.find((x) => x.id === id);
        return patch(s, id, {
          checklist: { ...(n.checklist || {}), [passoId]: valor },
          ultima_interacao: agora(),
          adiado_ate: null,
        });
      }),

    registrarContato: (id) =>
      setEstado((s) => {
        const n = s.negocios.find((x) => x.id === id);
        return patch(s, id, {
          ultima_interacao: agora(),
          adiado_ate: null,
          checklist: { ...(n.checklist || {}), contato: true },
        });
      }),

    concluirEtapa: (n) => {
      const proxima = ROTEIRO[n.etapa_funil]?.proxima;
      if (proxima) moverNegocio(n.id, proxima);
    },

    adiar: (id, dias) => {
      setEstado((s) => patch(s, id, { adiado_ate: new Date(Date.now() + dias * 864e5).toISOString() }));
      toast(dias === 1 ? "Guardado para amanhã." : `Guardado para daqui a ${dias} dias.`, "ok");
    },

    marcarPerdido: (n) => moverNegocio(n.id, "Perdido"),

    /* --- atendimento: os sinais alimentam temperatura, perfil e risco --- */
    marcarSinal: (id, sinalId, valor) =>
      setEstado((s) => {
        const n = s.negocios.find((x) => x.id === id);
        return patch(s, id, { sinais: { ...(n.sinais || {}), [sinalId]: valor } });
      }),

    definirPerfil: (id, perfilId) => setEstado((s) => patch(s, id, { perfil_manual: perfilId })),

    /* --- Fase 4: a conversa real dentro do card ---
       registrarMensagemCliente é o simulador de ENTRADA (modo ensaio):
       você cola/digita o que o cliente escreveu e ela entra no fio,
       preenchendo sozinha ultima_mensagem e ultima_interacao — que
       antes você digitava à mão. Quando o webhook real da Meta entrar,
       ele chama exatamente este mesmo caminho de dados. */
    registrarMensagemCliente: (id, texto, ts) =>
      setEstado((s) => {
        const t = String(texto || "").trim();
        if (!t) return s;
        const n = s.negocios.find((x) => x.id === id);
        const msg = novaMensagem({ direcao: DIRECAO.ENTRADA, texto: t, ts });
        return patch(s, id, {
          conversa: anexarMensagem(n.conversa, msg),
          ultima_mensagem: t,           // alimenta o painel de atendimento
          ultima_interacao: msg.ts,     // a fila e o SLA leem daqui
        });
      }),

    /* enviarMensagem registra a SAÍDA no fio. No modo ensaio o disparo
       de verdade continua pelo link wa.me (a UI abre o WhatsApp); aqui
       guardamos o que foi dito para o histórico bater com a realidade.
       registrarContato já reinicia o prazo da etapa — reusamos a mesma
       ideia marcando ultima_interacao. */
    enviarMensagem: (id, texto) =>
      setEstado((s) => {
        const t = String(texto || "").trim();
        if (!t) return s;
        const n = s.negocios.find((x) => x.id === id);
        const msg = novaMensagem({ direcao: DIRECAO.SAIDA, texto: t });
        return patch(s, id, {
          conversa: anexarMensagem(n.conversa, msg),
          ultima_interacao: msg.ts,
          checklist: { ...(n.checklist || {}), contato: true },
          adiado_ate: null,
        });
      }),

    /* --- jornada pós-venda: 15 marcos que estavam sem tela --- */
    marcarMarco: (id, marcoId, valor) =>
      setEstado((s) => {
        const n = s.negocios.find((x) => x.id === id);
        return patch(s, id, {
          checklist_jornada: { ...(n.checklist_jornada || {}), [marcoId]: valor },
          ultima_interacao: agora(),
        });
      }),

    /* --- prospecção: o gatilho não volta para o mesmo cliente --- */
    prospeccaoFeita: (clienteId, gatilhoId) =>
      setEstado((s) => ({
        ...s,
        clientes: s.clientes.map((c) =>
          c.id !== clienteId ? c : { ...c, prospeccao_feita: { ...(c.prospeccao_feita || {}), [gatilhoId]: true } }
        ),
      })),

    /* --- financeiro: dar baixa recalcula a trava do bilhete sozinha --- */
    togglePagoParcela: (id, numero) =>
      setEstado((s) => {
        const n = s.negocios.find((x) => x.id === id);
        return patch(s, id, {
          parcelas: (n.parcelas || []).map((p) =>
            p.n !== numero ? p : { ...p, pago: !p.pago, pago_em: !p.pago ? hojeISO() : null }
          ),
        });
      }),

    /* --- Fase 3: enviar conversões ao Google Ads ---
       Em produção, o endpoint do servidor faz o envio real e marca
       o estado. Em dev/local (sem servidor), marcamos aqui para você
       ver o fluxo funcionando de ponta a ponta. */
    enviarConversoes: async () => {
      const secret = import.meta.env?.VITE_CRON_SECRET;
      const podeChamarServidor = Boolean(secret);

      if (podeChamarServidor) {
        try {
          const r = await fetch(`/api/enviar-conversoes?secret=${encodeURIComponent(secret)}`, { method: "POST" });
          const j = await r.json();
          if (j.modo === "ensaio") toast(`Modo ensaio: ${j.enviariaAgora} conversão(ões) prontas. Configure GOOGLE_ADS_* para enviar de verdade.`, "ia");
          else toast(`${j.enviadas || 0} conversão(ões) enviada(s) ao Google Ads.`, "ok");
          // recarrega o estado do servidor para refletir o que foi marcado
          const novo = await carregarEstado();
          if (novo) setEstado(migrar(novo));
          return;
        } catch (e) {
          toast("Não consegui falar com o servidor de conversões. Marquei localmente.", "erro");
        }
      }

      // Fallback local: marca as prontas como enviadas, para o fluxo fechar.
      setEstado((st) => {
        const clientePor = (cid) => st.clientes.find((c) => c.id === cid);
        let n = 0;
        const negocios = st.negocios.map((neg) => {
          const c = clientePor(neg.cliente_id);
          if (statusConversao(neg, c) === STATUS_CONVERSAO.PRONTA) {
            const conv = montarConversao(neg, c);
            n++;
            return { ...neg, conversao: { enviada: true, enviada_em: agora(), valor: conv.conversionValue } };
          }
          return neg;
        });
        const novo = n
          ? log({ ...st, negocios }, "Conversão Ads", `${n} conversão(ões) preparada(s) para o Google Ads (margem como valor).`)
          : st;
        return novo;
      });
    },

    marcarCruzeiro: (id, itemId, valor) =>
      setEstado((s) => {
        const n = s.negocios.find((x) => x.id === id);
        return patch(s, id, { checklist_cruzeiro: { ...(n.checklist_cruzeiro || {}), [itemId]: valor } });
      }),

    concluirTarefa: (id) =>
      setEstado((s) => ({
        ...s,
        tarefas: s.tarefas.map((t) => (t.id === id ? { ...t, status: "Concluída", concluida_em: agora() } : t)),
      })),

    reabrirTarefa: (id) =>
      setEstado((s) => ({ ...s, tarefas: s.tarefas.map((t) => (t.id === id ? { ...t, status: "Pendente" } : t)) })),

    excluirTarefa: (id) => setEstado((s) => ({ ...s, tarefas: s.tarefas.filter((t) => t.id !== id) })),

    alternarAgente: (chave) =>
      setEstado((s) => {
        const ligado = !s.agentes[chave];
        const nome = chave === "marketing" ? "Agente de Marketing" : "Agente de Vendas";
        return log({ ...s, agentes: { ...s.agentes, [chave]: ligado } }, "Sistema", `${nome} ${ligado ? "ligado" : "desligado"}.`);
      }),

    verificarAgora: () => verificar(false),

    envelhecer: () => {
      setEstado((s) => ({
        ...s,
        negocios: s.negocios.map((n) => ({
          ...n,
          ultima_interacao: horasAtras(horasDesde(n.ultima_interacao) + 48),
          adiado_ate: null,
        })),
      }));
      toast("Simulação: todos os clientes ficaram 48h mais antigos.", "ia");
      setTimeout(() => verificar(true), 400);
    },

    exportar: () => {
      exportarBackup(ref.current);
      toast("Backup baixado. Guarde fora do computador.", "ok");
    },

    importar: async (arquivo) => {
      try {
        const dados = await importarBackup(arquivo);
        if (!dados.negocios || !dados.clientes) throw new Error("Backup sem os dados esperados.");
        setEstado(dados);
        toast("Backup restaurado.", "ok");
      } catch (e) {
        toast(e.message, "erro");
      }
    },

    restaurarDemo: () => {
      setEstado(dadosIniciais());
      toast("Base restaurada para a demonstração.", "ok");
    },

    /* --- acesso: tranca da porta de entrada --- */
    bloquear: () => {
      try { sessionStorage.removeItem("crm3lg:sessao"); } catch {}
      setDesbloqueado(false);
    },

    /* Trocar login/senha: apaga a credencial atual e volta para a tela
       de "criar acesso". Como a senha nunca é guardada em texto, não há
       "ver a atual" — o caminho é definir uma nova. */
    trocarAcesso: () => {
      setEstado((s) => ({ ...s, acesso: null }));
      try { sessionStorage.removeItem("crm3lg:sessao"); } catch {}
      setDesbloqueado(false);
      toast("Defina um novo login e senha.", "ok");
    },
  };

  const salvarNegocio = (f) => {
    setEstado((s) => {
      if (f.id) {
        return {
          ...s,
          clientes: s.clientes.map((c) =>
            c.id === f.cliente_id ? { ...c, nome: f.nome, whatsapp: f.whatsapp, email: f.email, origem: f.origem, gclid: f.gclid || null, gclid_em: f.gclid_em || null } : c
          ),
          negocios: s.negocios.map((n) =>
            n.id === f.id
              ? {
                  ...n,
                  destino: f.destino,
                  data_ida: f.data_ida,
                  data_volta: f.data_volta,
                  num_pessoas: Number(f.num_pessoas) || 1,
                  orcamento: Number(f.orcamento) || 0,
                  tipo: f.tipo,
                  motivo_viagem: f.motivo_viagem,
                  notas: f.notas,
                  motivo_perda: f.motivo_perda,
                  valor_venda: Number(f.valor_venda) || 0,
                  custo: Number(f.custo) || 0,
                  parcelas: f.parcelas || [],
                  localizador: f.localizador || "",
                  fornecedores: f.fornecedores || [],
                  ultima_mensagem: f.ultima_mensagem,
                  conversa: f.conversa || n.conversa || [],
                  sinais: f.sinais || {},
                  perfil_manual: f.perfil_manual || "",
                  cruzeiro: f.cruzeiro || {},
                  ultima_interacao: agora(),
                }
              : n
          ),
        };
      }
      const cid = uid();
      const novo = {
        ...s,
        clientes: [...s.clientes, { id: cid, nome: f.nome, whatsapp: f.whatsapp, email: f.email, origem: f.origem, gclid: f.gclid || null, gclid_em: f.gclid_em || null, prospeccao_feita: {} }],
        negocios: [
          {
            id: uid(),
            cliente_id: cid,
            destino: f.destino,
            data_ida: f.data_ida,
            data_volta: f.data_volta,
            num_pessoas: Number(f.num_pessoas) || 1,
            orcamento: Number(f.orcamento) || 0,
            tipo: f.tipo,
            motivo_viagem: f.motivo_viagem,
            notas: f.notas,
            valor_venda: 0,
            motivo_perda: "",
            etapa_funil: "Novo Lead",
            ultima_interacao: agora(),
            checklist: {},
            checklist_jornada: {},
            adiado_ate: null,
            custo: 0,
            parcelas: [],
            localizador: "",
            data_fechamento: "",
            fornecedores: [],
            sinais: f.sinais || {},
            perfil_manual: "",
            ultima_mensagem: f.ultima_mensagem || "",
            conversa: [],
            cruzeiro: f.cruzeiro || {},
            checklist_cruzeiro: {},
          },
          ...s.negocios,
        ],
      };
      return log(novo, "Sistema", `Novo lead: ${f.nome} (${f.origem}).`);
    });
    setModal(null);
    toast(f.id ? "Dados atualizados." : "Lead na fila. Responda nos próximos minutos.", "ok");
  };

  const excluirNegocio = (id) => {
    setEstado((s) => ({
      ...s,
      negocios: s.negocios.filter((n) => n.id !== id),
      tarefas: s.tarefas.filter((t) => t.negocio_id !== id),
    }));
    setModal(null);
    toast("Negócio removido.", "ok");
  };

  if (!estado) {
    return (
      <div className="flex h-screen items-center justify-center bg-slate-50 text-slate-500">
        <RefreshCw className="mr-2 animate-spin" size={18} /> Abrindo seu CRM...
      </div>
    );
  }

  // Porta de entrada: primeiro acesso cria a tranca; depois, pede senha.
  // Nada é embutido no código — a credencial nasce aqui, no navegador.
  if (!temAcesso(estado)) {
    return (
      <TelaAcesso
        modo="criar"
        onCriar={(cred) => {
          setEstado((s) => ({ ...s, acesso: cred }));
          abrirSessao();
        }}
      />
    );
  }
  if (!desbloqueado) {
    return <TelaAcesso modo="entrar" acesso={estado.acesso} onEntrar={abrirSessao} />;
  }

  const resumo = resumoDoDia(estado);
  const fin = resumoFinanceiro(estado);

  return (
    <div className="flex h-screen w-full bg-slate-100 font-sans text-slate-800">
      <aside className="flex w-60 flex-shrink-0 flex-col bg-slate-900 text-slate-300">
        <div className="border-b border-slate-800 px-5 py-5">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-blue-600 font-bold text-white">3</div>
            <div>
              <p className="text-sm font-semibold tracking-wide text-white">3LG TURISMO</p>
              <p className="text-xs text-slate-400">CRM do Leonardo</p>
            </div>
          </div>
        </div>

        <nav className="flex flex-1 flex-col gap-1 p-3">
          <Item ativo={tela === "agora"} onClick={() => setTela("agora")} icone={Zap} texto="Agora" badge={resumo.atrasados} destaque />
          <Item ativo={tela === "funil"} onClick={() => setTela("funil")} icone={LayoutGrid} texto="Funil" />
          <Item ativo={tela === "dinheiro"} onClick={() => setTela("dinheiro")} icone={Wallet} texto="Dinheiro" badge={fin.qtdVencidas} />
          <Item ativo={tela === "tarefas"} onClick={() => setTela("tarefas")} icone={CheckSquare} texto="Tarefas do dia" badge={resumo.tarefas} />
          <Item ativo={tela === "ia"} onClick={() => setTela("ia")} icone={Bot} texto="Centro de Comando IA" />
        </nav>

        <div className="border-t border-slate-800 p-4">
          <p className="mb-2 text-xs uppercase tracking-wider text-slate-500">Agentes</p>
          <Status nome="Marketing" ligado={estado.agentes.marketing} />
          <Status nome="Vendas" ligado={estado.agentes.vendas} />
          <button
            onClick={acoes.bloquear}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg border border-slate-700 px-3 py-2 text-xs font-medium text-slate-300 transition hover:bg-slate-800"
          >
            <Lock size={13} /> Bloquear
          </button>
        </div>
      </aside>

      <main className="flex flex-1 flex-col overflow-hidden">
        <header className="flex items-center justify-between border-b border-slate-200 bg-white px-8 py-4">
          <div>
            <h1 className="text-lg font-semibold text-slate-900">
              {tela === "agora" && "Agora"}
              {tela === "funil" && "Funil"}
              {tela === "dinheiro" && "Dinheiro"}
              {tela === "tarefas" && "Tarefas do dia"}
              {tela === "ia" && "Centro de Comando IA"}
            </h1>
            <p className="text-sm text-slate-500">
              {tela === "agora" && "Um cliente por vez, na ordem que dá mais resultado."}
              {tela === "funil" && "Visão geral. A etapa de proposta exige qualificação completa."}
              {tela === "tarefas" && "Pendências criadas pelos agentes."}
              {tela === "ia" && "O que os agentes fizeram em segundo plano."}
            </p>
          </div>
          <button
            onClick={() => setModal({ modo: "novo" })}
            className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700"
          >
            <Plus size={16} /> Novo lead
          </button>
        </header>

        <div className="flex-1 overflow-auto">
          {tela === "agora" && <Agora estado={estado} cliente={clienteDe} acoes={acoes} toast={toast} />}
          {tela === "funil" && <Funil estado={estado} cliente={clienteDe} moverNegocio={moverNegocio} abrirEdicao={acoes.abrirEdicao} />}
          {tela === "dinheiro" && <Dinheiro estado={estado} acoes={acoes} toast={toast} />}
          {tela === "tarefas" && <Tarefas estado={estado} cliente={clienteDe} acoes={acoes} toast={toast} />}
          {tela === "ia" && <ComandoIA estado={estado} acoes={acoes} />}
        </div>
      </main>

      {modal && (
        <ModalNegocio
          modo={modal.modo}
          negocio={modal.negocio}
          cliente={modal.negocio ? clienteDe(modal.negocio.cliente_id) : null}
          onSalvar={salvarNegocio}
          onExcluir={excluirNegocio}
          onFechar={() => setModal(null)}
        />
      )}

      <Toasts itens={toasts} remover={(id) => setToasts((t) => t.filter((x) => x.id !== id))} />
    </div>
  );
}

function Item({ ativo, onClick, icone: Icone, texto, badge, destaque }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition ${
        ativo ? "bg-blue-600 font-medium text-white" : "text-slate-300 hover:bg-slate-800"
      }`}
    >
      <Icone size={18} className={!ativo && destaque ? "text-amber-400" : ""} />
      <span className="flex-1 text-left">{texto}</span>
      {badge > 0 && (
        <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${ativo ? "bg-white text-blue-700" : "bg-amber-500 text-white"}`}>
          {badge}
        </span>
      )}
    </button>
  );
}

function Status({ nome, ligado }) {
  return (
    <div className="flex items-center gap-2 py-1 text-xs">
      <span className={`h-2 w-2 rounded-full ${ligado ? "animate-pulse bg-emerald-400" : "bg-slate-600"}`} />
      <span className={ligado ? "text-slate-300" : "text-slate-500"}>{nome}</span>
      <span className="ml-auto text-slate-500">{ligado ? "ativo" : "parado"}</span>
    </div>
  );
}
