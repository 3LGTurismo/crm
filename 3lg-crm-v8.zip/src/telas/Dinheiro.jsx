import React, { useState } from "react";
import { Wallet, AlertTriangle, CheckCircle2, Circle, TrendingUp, Search, Target, Check, Clock, Link2 } from "lucide-react";
import { fmtMoeda, fmtData, hojeISO, primeiroNome } from "../lib/dominio.js";
import {
  resumoFinanceiro, todasParcelas, margem, margemPercentual, statusPagamento,
  saldoAberto, divergenciaParcelas,
} from "../lib/financeiro.js";
import { resumoConversoes, VALIDADE_GCLID_DIAS } from "../lib/conversao.js";

export default function Dinheiro({ estado, acoes, toast }) {
  const [aba, setAba] = useState("receber");
  const [busca, setBusca] = useState("");
  const fin = resumoFinanceiro(estado);
  const conv = resumoConversoes(estado);
  const hoje = hojeISO();

  const parcelas = todasParcelas(estado);
  const pendentes = parcelas
    .filter((p) => !p.pago)
    .sort((a, b) => a.vencimento.localeCompare(b.vencimento));
  const recebidas = parcelas
    .filter((p) => p.pago)
    .sort((a, b) => (b.pago_em || "").localeCompare(a.pago_em || ""));

  const vendas = estado.negocios
    .filter((n) => n.etapa_funil === "Fechado")
    .sort((a, b) => (b.data_fechamento || "").localeCompare(a.data_fechamento || ""));

  const filtra = (lista) => {
    const q = busca.trim().toLowerCase();
    if (!q) return lista;
    return lista.filter((x) => {
      const nome = x.cliente?.nome || estado.clientes.find((c) => c.id === x.cliente_id)?.nome || "";
      const destino = x.negocio?.destino || x.destino || "";
      return `${nome} ${destino}`.toLowerCase().includes(q);
    });
  };

  const divergentes = vendas.filter((n) => divergenciaParcelas(n) !== 0);

  return (
    <div className="mx-auto max-w-3xl space-y-5 p-6 pb-16">
      <div>
        <h2 className="text-xl font-semibold text-slate-900">Dinheiro</h2>
        <p className="mt-0.5 text-sm text-slate-500">
          O que entrou, o que falta entrar e quanto sobrou de verdade.
        </p>
      </div>

      {/* Caixa */}
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Caixa rotulo="Recebido no mês" valor={fmtMoeda(fin.recebidoMes)} />
        <Caixa rotulo="A receber" valor={fmtMoeda(fin.aReceber)} sub={`${pendentes.length} parcela(s)`} />
        <Caixa rotulo="Vencido" valor={fmtMoeda(fin.vencido)} sub={fin.qtdVencidas ? `${fin.qtdVencidas} parcela(s)` : "nada em atraso"} alerta={fin.vencido > 0} />
        <Caixa rotulo="Margem do mês" valor={fmtMoeda(fin.margemMes)} sub={`sobre ${fmtMoeda(fin.vendidoMes)} vendidos`} />
      </div>

      {/* Divergência: erro de digitação vira cobrança errada com o cliente */}
      {divergentes.length > 0 && (
        <div className="rounded-xl bg-amber-50 p-4 ring-1 ring-amber-200">
          <p className="flex items-center gap-1.5 text-sm font-semibold text-amber-900">
            <AlertTriangle size={15} /> A soma das parcelas não bate com o valor da venda
          </p>
          <p className="mt-1 text-xs leading-relaxed text-amber-800">
            Enquanto não bater, o pagamento nunca chega a "Pago" — e a trava do bilhete não libera.
          </p>
          <div className="mt-3 space-y-1">
            {divergentes.map((n) => {
              const c = estado.clientes.find((x) => x.id === n.cliente_id);
              const d = divergenciaParcelas(n);
              return (
                <button
                  key={n.id}
                  onClick={() => acoes.abrirEdicao(n)}
                  className="flex w-full items-center gap-2 rounded-lg bg-white px-3 py-2 text-left ring-1 ring-amber-200 hover:bg-amber-50"
                >
                  <span className="flex-1 text-xs font-medium text-slate-700">{c?.nome} · {n.destino}</span>
                  <span className="text-xs text-slate-500">venda {fmtMoeda(n.valor_venda)}</span>
                  <span className="text-xs font-semibold text-amber-700">
                    {d > 0 ? "+" : ""}{fmtMoeda(d)} nas parcelas
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Abas */}
      <div className="flex items-center gap-2">
        {[
          { id: "receber", t: `A receber (${pendentes.length})` },
          { id: "recebido", t: `Recebido (${recebidas.length})` },
          { id: "margem", t: `Margem (${vendas.length})` },
          { id: "ads", t: `Google Ads (${conv.prontas.length})` },
        ].map((x) => (
          <button
            key={x.id}
            onClick={() => setAba(x.id)}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${
              aba === x.id ? "bg-slate-800 text-white" : "bg-white text-slate-500 ring-1 ring-slate-200 hover:bg-slate-50"
            }`}
          >
            {x.t}
          </button>
        ))}
        <div className="relative ml-auto">
          <Search size={13} className="absolute left-2.5 top-2 text-slate-400" />
          <input
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            placeholder="Buscar"
            className="w-40 rounded-lg border border-slate-200 py-1.5 pl-7 pr-2 text-xs focus:outline-none focus:ring-1 focus:ring-blue-400"
          />
        </div>
      </div>

      {/* Listas */}
      <div className="overflow-hidden rounded-xl bg-white ring-1 ring-slate-200">
        {aba === "receber" &&
          (filtra(pendentes).length === 0 ? (
            <Vazio texto="Nenhuma parcela em aberto." />
          ) : (
            filtra(pendentes).map((p) => <Linha key={p.negocio_id + p.n} p={p} hoje={hoje} acoes={acoes} toast={toast} />)
          ))}

        {aba === "recebido" &&
          (filtra(recebidas).length === 0 ? (
            <Vazio texto="Nada recebido ainda." />
          ) : (
            filtra(recebidas).map((p) => <Linha key={p.negocio_id + p.n} p={p} hoje={hoje} acoes={acoes} toast={toast} />)
          ))}

        {aba === "ads" && <AbaAds conv={conv} acoes={acoes} toast={toast} />}

        {aba === "margem" &&
          (vendas.length === 0 ? (
            <Vazio texto="Nenhuma venda fechada ainda." />
          ) : (
            filtra(vendas.map((n) => ({ negocio: n, cliente: estado.clientes.find((c) => c.id === n.cliente_id) }))).map(
              ({ negocio: n, cliente: c }) => <LinhaMargem key={n.id} n={n} c={c} acoes={acoes} />
            )
          ))}
      </div>

      {aba !== "ads" && (
        <p className="px-1 text-xs leading-relaxed text-slate-400">
          A margem é o que a Fase 3 envia ao Google Ads como valor de conversão. É por isso que o
          campo <strong>custo</strong> importa: sem ele, o algoritmo persegue clique — com ele, persegue lucro.
        </p>
      )}
    </div>
  );
}

function Linha({ p, hoje, acoes, toast }) {
  const vencida = !p.pago && p.vencimento < hoje;
  return (
    <div className="flex items-center gap-3 border-b border-slate-100 px-4 py-3 last:border-0">
      <button
        onClick={() => {
          acoes.togglePagoParcela(p.negocio_id, p.n);
          toast(p.pago ? "Baixa desfeita." : "Parcela recebida.", "ok");
        }}
        className="flex-shrink-0"
        aria-label={p.pago ? "Desfazer baixa" : "Dar baixa"}
      >
        {p.pago ? (
          <CheckCircle2 size={18} className="text-emerald-500" />
        ) : (
          <Circle size={18} className={vencida ? "text-rose-400" : "text-slate-300"} />
        )}
      </button>
      <div className="min-w-0 flex-1">
        <p className={`truncate text-sm font-medium ${p.pago ? "text-slate-400" : "text-slate-800"}`}>
          {p.cliente?.nome} · {p.negocio.destino}
        </p>
        <p className={`text-xs ${vencida ? "font-medium text-rose-600" : "text-slate-400"}`}>
          Parcela {p.n} · {p.pago ? `paga em ${fmtData(p.pago_em)}` : vencida ? `venceu em ${fmtData(p.vencimento)}` : `vence em ${fmtData(p.vencimento)}`}
        </p>
      </div>
      <span className={`text-sm font-semibold ${p.pago ? "text-slate-400" : "text-slate-800"}`}>{fmtMoeda(p.valor)}</span>
    </div>
  );
}

function LinhaMargem({ n, c, acoes }) {
  const m = margem(n);
  const pct = margemPercentual(n);
  const semCusto = !Number(n.custo);
  return (
    <button
      onClick={() => acoes.abrirEdicao(n)}
      className="flex w-full items-center gap-3 border-b border-slate-100 px-4 py-3 text-left last:border-0 hover:bg-slate-50"
    >
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-slate-800">{c?.nome} · {n.destino}</p>
        <p className="text-xs text-slate-400">
          {statusPagamento(n)}
          {saldoAberto(n) > 0 ? ` · ${fmtMoeda(saldoAberto(n))} em aberto` : ""}
          {n.data_fechamento ? ` · fechado em ${fmtData(n.data_fechamento)}` : ""}
        </p>
      </div>
      <div className="text-right">
        <p className="text-sm font-semibold text-slate-800">{fmtMoeda(n.valor_venda)}</p>
        {semCusto ? (
          <p className="text-xs font-medium text-amber-600">falta o custo</p>
        ) : (
          <p className={`text-xs font-medium ${m >= 0 ? "text-emerald-600" : "text-rose-600"}`}>
            {fmtMoeda(m)} · {pct.toFixed(0)}%
          </p>
        )}
      </div>
    </button>
  );
}

function Caixa({ rotulo, valor, sub, alerta }) {
  return (
    <div className={`rounded-xl p-3 ring-1 ${alerta ? "bg-rose-50 ring-rose-200" : "bg-white ring-slate-200"}`}>
      <p className={`text-xs ${alerta ? "text-rose-600" : "text-slate-400"}`}>{rotulo}</p>
      <p className={`mt-0.5 text-base font-bold ${alerta ? "text-rose-700" : "text-slate-800"}`}>{valor}</p>
      {sub && <p className="mt-0.5 text-xs text-slate-400">{sub}</p>}
    </div>
  );
}

function Vazio({ texto }) {
  return (
    <div className="px-4 py-10 text-center">
      <Wallet size={22} className="mx-auto mb-2 text-slate-300" />
      <p className="text-sm text-slate-400">{texto}</p>
    </div>
  );
}

/* ============================================================
   Aba Google Ads — a Fase 3 na tela
   ============================================================ */
function AbaAds({ conv, acoes, toast }) {
  const taxa = conv.totalFechados > 0 ? Math.round((conv.capturados / conv.totalFechados) * 100) : 0;

  return (
    <div className="p-4">
      {/* topo: o que está indo para o Google */}
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
        <Mini rotulo="Prontas para enviar" valor={conv.prontas.length} destaque={conv.prontas.length > 0} />
        <Mini rotulo="Margem a enviar" valor={fmtMoeda(conv.margemPronta)} />
        <Mini rotulo="Já enviadas" valor={conv.enviadas.length} />
        <Mini rotulo="Captura de clique" valor={`${taxa}%`} alerta={taxa < 50 && conv.totalFechados > 0} />
      </div>

      {conv.prontas.length > 0 && (
        <button
          onClick={() => { acoes.enviarConversoes(); toast("Pedido de envio registrado. No servidor, o Google recebe gclid + margem.", "ok"); }}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white transition hover:bg-blue-700"
        >
          <Target size={16} /> Enviar {conv.prontas.length} conversão(ões) ao Google Ads
        </button>
      )}

      {/* explicação honesta do que o botão faz */}
      <div className="mt-3 rounded-lg bg-blue-50 p-3 text-xs leading-relaxed text-blue-900 ring-1 ring-blue-100">
        Cada conversão leva o <strong>código do clique</strong> que originou o lead mais a <strong>margem</strong> daquela venda.
        Com isso, o Google Ads deixa de otimizar por "clicou no WhatsApp" e passa a perseguir cliente que dá lucro.
        O envio real acontece no servidor (endpoint <code>/api/enviar-conversoes</code>); aqui você acompanha e dispara.
      </div>

      {/* prontas */}
      {conv.prontas.length > 0 && (
        <Bloco titulo="Prontas para enviar" cor="emerald">
          {conv.prontas.map(({ negocio: n, cliente: c, margem: m }) => (
            <LinhaConv key={n.id} nome={c?.nome} destino={n.destino} valor={fmtMoeda(m)} nota="margem" />
          ))}
        </Bloco>
      )}

      {/* travadas: sem custo */}
      {conv.sem_margem.length > 0 && (
        <Bloco titulo="Travadas: falta o custo" cor="amber">
          <p className="mb-2 px-1 text-xs text-amber-700">
            Vieram de anúncio e têm o clique, mas sem o custo não há margem para enviar. Preencha o custo na venda.
          </p>
          {conv.sem_margem.map(({ negocio: n, cliente: c }) => (
            <button key={n.id} onClick={() => acoes.abrirEdicao(n)} className="flex w-full items-center gap-2 rounded-lg bg-white px-3 py-2 text-left ring-1 ring-amber-200 hover:bg-amber-50">
              <span className="flex-1 text-xs font-medium text-slate-700">{c?.nome} · {n.destino}</span>
              <span className="text-xs font-medium text-amber-700">preencher custo →</span>
            </button>
          ))}
        </Bloco>
      )}

      {/* sem clique capturado */}
      {conv.sem_clique.length > 0 && (
        <Bloco titulo="Sem clique capturado" cor="slate">
          <p className="mb-2 px-1 text-xs text-slate-500">
            Fecharam, mas não têm o código do clique. Ou não vieram de anúncio, ou o gclid não foi colado no cadastro.
            Se vieram do Google Ads, abra o cliente e cole o código.
          </p>
          {conv.sem_clique.slice(0, 6).map(({ negocio: n, cliente: c }) => (
            <button key={n.id} onClick={() => acoes.abrirEdicao(n)} className="flex w-full items-center gap-2 rounded-lg bg-white px-3 py-2 text-left ring-1 ring-slate-200 hover:bg-slate-50">
              <span className="flex-1 text-xs font-medium text-slate-700">{c?.nome} · {n.destino}</span>
              <span className="text-xs text-slate-400">{c?.origem}</span>
            </button>
          ))}
        </Bloco>
      )}

      {/* expiradas */}
      {conv.expiradas.length > 0 && (
        <Bloco titulo="Expiradas" cor="slate">
          <p className="mb-2 px-1 text-xs text-slate-500">
            O clique tem mais de {VALIDADE_GCLID_DIAS} dias — o Google não aceita mais. Fecharam tarde demais depois do clique.
          </p>
          {conv.expiradas.map(({ negocio: n, cliente: c }) => (
            <LinhaConv key={n.id} nome={c?.nome} destino={n.destino} valor="—" nota="fora do prazo" />
          ))}
        </Bloco>
      )}

      {/* já enviadas */}
      {conv.enviadas.length > 0 && (
        <Bloco titulo="Já enviadas ao Google" cor="slate">
          {conv.enviadas.map(({ negocio: n, cliente: c, margem: m }) => (
            <LinhaConv key={n.id} nome={c?.nome} destino={n.destino} valor={fmtMoeda(m)} nota="enviada" ok />
          ))}
        </Bloco>
      )}

      {conv.totalFechados === 0 && (
        <div className="mt-6 text-center">
          <Target size={22} className="mx-auto mb-2 text-slate-300" />
          <p className="text-sm text-slate-400">Nenhuma venda fechada ainda. As conversões aparecem aqui quando você fechar.</p>
        </div>
      )}
    </div>
  );
}

function Mini({ rotulo, valor, destaque, alerta }) {
  return (
    <div className={`rounded-xl p-3 ring-1 ${destaque ? "bg-emerald-50 ring-emerald-200" : alerta ? "bg-amber-50 ring-amber-200" : "bg-white ring-slate-200"}`}>
      <p className={`text-xs ${alerta ? "text-amber-600" : destaque ? "text-emerald-600" : "text-slate-400"}`}>{rotulo}</p>
      <p className={`mt-0.5 text-base font-bold ${alerta ? "text-amber-700" : destaque ? "text-emerald-700" : "text-slate-800"}`}>{valor}</p>
    </div>
  );
}

function Bloco({ titulo, cor, children }) {
  return (
    <div className="mt-5">
      <p className="mb-2 px-1 text-xs font-semibold uppercase tracking-wider text-slate-400">{titulo}</p>
      <div className="space-y-1">{children}</div>
    </div>
  );
}

function LinhaConv({ nome, destino, valor, nota, ok }) {
  return (
    <div className="flex items-center gap-3 rounded-lg bg-white px-3 py-2 ring-1 ring-slate-200">
      {ok ? <Check size={14} className="text-emerald-500" /> : <Link2 size={14} className="text-slate-300" />}
      <span className="flex-1 truncate text-sm font-medium text-slate-700">{nome} · {destino}</span>
      <span className="text-xs text-slate-400">{nota}</span>
      <span className="w-24 text-right text-sm font-semibold text-slate-800">{valor}</span>
    </div>
  );
}
