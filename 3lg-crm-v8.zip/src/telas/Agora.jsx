import React, { useState } from "react";
import {
  MapPin, Calendar, Users, Wallet, Copy, MessageCircle, Check, ArrowRight, Clock,
  ThumbsDown, Sun, Circle, CheckCircle2, Lightbulb, Pencil, ChevronRight, Flame,
  Plane, Gift, Lock, TrendingUp, BadgeDollarSign,
} from "lucide-react";
import {
  ROTEIRO, OBJECOES, PONTO_ETAPA, fmtMoeda, fmtData, rotuloTempo, diasAte, primeiroNome,
  progressoEtapa, proximoPasso, passoConcluido, qualificacaoCompleta, camposFaltando,
} from "../lib/dominio.js";
import { slaEstourado, resumoDoDia } from "../lib/motor.js";
import { filaCompleta, resumoFila, CAMADAS, ROTULO_CAMADA } from "../lib/fila.js";
import { COR_FASE, progressoJornada } from "../lib/jornada.js";
import { temperatura, COR_TEMPERATURA } from "../lib/atendimento.js";
import { resumoFinanceiro, statusPagamento, parcelasVencidas, valorVencido, saldoAberto } from "../lib/financeiro.js";
import PainelAtendimento from "../componentes/PainelAtendimento.jsx";

const linkWhats = (numero, texto) => {
  const d = String(numero || "").replace(/\D/g, "");
  const completo = d.startsWith("55") ? d : `55${d}`;
  return `https://wa.me/${completo}?text=${encodeURIComponent(texto || "")}`;
};

const saudacao = () => {
  const h = new Date().getHours();
  if (h < 12) return "Bom dia";
  if (h < 18) return "Boa tarde";
  return "Boa noite";
};

export default function Agora({ estado, acoes, toast }) {
  const fila = filaCompleta(estado);
  const [selecionado, setSelecionado] = useState(null);
  const resumo = resumoDoDia(estado);
  const rf = resumoFila(estado);
  const fin = resumoFinanceiro(estado);

  const item = fila.find((x) => x.id === selecionado) || fila[0];

  if (!item) {
    return (
      <div className="mx-auto max-w-2xl p-8">
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-12 text-center">
          <Sun size={30} className="mx-auto mb-4 text-amber-400" />
          <h2 className="text-lg font-semibold text-slate-800">Fila limpa.</h2>
          <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-slate-500">
            Ninguém esperando, nenhuma viagem pedindo cuidado, nenhuma parcela em aberto e nada para prospectar hoje.
          </p>
          <button onClick={() => acoes.novoLead()} className="mt-5 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-blue-700">
            Cadastrar um lead
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-5 p-6 pb-16">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold text-slate-900">{saudacao()}, Leonardo.</h2>
          <p className="mt-0.5 text-sm text-slate-500">
            {rf.urgentes > 0
              ? `${rf.urgentes} ${rf.urgentes === 1 ? "item urgente" : "itens urgentes"} na frente. Comece por este.`
              : "Nada urgente. Este é o próximo da fila."}
          </p>
        </div>
        <div className="flex flex-wrap gap-4 text-right">
          <Metrica valor={resumo.abertos} rotulo="em aberto" />
          <Metrica valor={resumo.atrasados} rotulo="atrasados" alerta={resumo.atrasados > 0} />
          <Metrica valor={fmtMoeda(resumo.emJogo)} rotulo="em jogo" />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <Caixa rotulo="A receber" valor={fmtMoeda(fin.aReceber)} />
        <Caixa rotulo="Vencido" valor={fmtMoeda(fin.vencido)} alerta={fin.vencido > 0} sub={fin.qtdVencidas ? `${fin.qtdVencidas} parcela(s)` : null} />
        <Caixa rotulo="Margem do mês" valor={fmtMoeda(fin.margemMes)} sub={fin.qtdVendasMes ? `${fin.qtdVendasMes} venda(s)` : null} />
      </div>

      {item.tipo === "venda" && <CardVenda item={item} acoes={acoes} toast={toast} />}
      {item.tipo === "cobranca" && <CardCobranca item={item} acoes={acoes} toast={toast} />}
      {item.tipo === "viagem" && <CardViagem item={item} acoes={acoes} toast={toast} />}
      {item.tipo === "prospeccao" && <CardProspeccao item={item} acoes={acoes} toast={toast} />}

      {fila.length > 1 && (
        <div>
          <p className="mb-2 px-1 text-xs font-semibold uppercase tracking-wider text-slate-400">Depois deste</p>
          <div className="space-y-2">
            {fila.slice(1, 8).map((x) => (
              <ItemFila key={x.id} item={x} onClick={() => setSelecionado(x.id)} />
            ))}
          </div>
          <p className="mt-3 px-1 text-xs text-slate-400">
            {rf.total} na fila · {rf.viagens} viagem(ns) · {rf.cobrancas} cobrança(s) · {rf.prospeccao} prospecção
          </p>
        </div>
      )}
    </div>
  );
}

/* ===================== CARD 1 — VENDA ===================== */

function CardVenda({ item, acoes, toast }) {
  const n = item.negocio;
  const c = item.cliente;
  const r = ROTEIRO[n.etapa_funil];
  const { feitos, total, pendentes } = progressoEtapa(n);
  const passo = proximoPasso(n);
  const script = r.script({ ...n, nome: c?.nome });
  const dias = diasAte(n.data_ida);
  const atrasado = slaEstourado(n);
  const podeAvancar = pendentes.length === 0 && r.proxima;
  const travadoPelaRegra = r.proxima === "Montando Proposta" && !qualificacaoCompleta(n);

  return (
    <div className="overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
      <Faixa tom={atrasado ? "amber" : "blue"} icone={atrasado ? Flame : Clock} texto={item.motivo} />
      <div className="p-6">
        <Topo c={c} n={n} acoes={acoes} />

        <div className="mt-4 grid grid-cols-2 gap-3 rounded-xl bg-slate-50 p-4 sm:grid-cols-4">
          <Dado icone={MapPin} rotulo="Destino" valor={n.destino || "—"} faltando={!n.destino} />
          <Dado icone={Calendar} rotulo="Ida" valor={n.data_ida ? fmtData(n.data_ida) : "—"} extra={dias !== null && dias >= 0 ? `em ${dias}d` : null} faltando={!n.data_ida} />
          <Dado icone={Users} rotulo="Pessoas" valor={n.num_pessoas || "—"} />
          <Dado icone={Wallet} rotulo="Orçamento" valor={fmtMoeda(Number(n.orcamento))} faltando={!Number(n.orcamento)} />
        </div>

        <PainelAtendimento negocio={n} cliente={c} acoes={acoes} toast={toast} />

        <div className="mt-6">
          <p className="text-sm font-semibold text-slate-900">{r.objetivo}</p>
          <p className="mt-1 text-sm leading-relaxed text-slate-500">{r.porque}</p>
        </div>

        <div className="mt-5">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Faça nesta ordem</p>
            <span className="text-xs text-slate-400">{feitos} de {total}</span>
          </div>
          <div className="space-y-1">
            {r.passos.map((p) => {
              const ok = passoConcluido(n, p);
              const atual = passo && p.id === passo.id;
              return (
                <button
                  key={p.id}
                  onClick={() => (p.campo && !ok ? acoes.abrirEdicao(n) : acoes.marcarPasso(n.id, p.id, !ok))}
                  className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition ${atual ? "bg-blue-50 ring-1 ring-blue-200" : "hover:bg-slate-50"}`}
                >
                  {ok ? <CheckCircle2 size={17} className="flex-shrink-0 text-emerald-500" /> : <Circle size={17} className={`flex-shrink-0 ${atual ? "text-blue-600" : "text-slate-300"}`} />}
                  <span className={`flex-1 text-sm ${ok ? "text-slate-400 line-through" : atual ? "font-medium text-slate-900" : "text-slate-600"}`}>{p.texto}</span>
                  {p.campo && !ok && <span className="text-xs text-blue-600">preencher</span>}
                </button>
              );
            })}
          </div>
        </div>

        {r.dica && (
          <div className="mt-4 flex items-start gap-2 rounded-lg bg-amber-50 p-3 text-xs leading-relaxed text-amber-900">
            <Lightbulb size={14} className="mt-0.5 flex-shrink-0" />
            <span>{r.dica}</span>
          </div>
        )}

        <Script texto={script} whats={c?.whatsapp} onEnviar={() => acoes.registrarContato(n.id)} toast={toast} />
        {n.etapa_funil === "Negociação" && <Objecoes negocio={{ ...n, nome: c?.nome }} toast={toast} />}
      </div>

      <div className="flex flex-wrap items-center gap-2 border-t border-slate-200 bg-slate-50 px-6 py-4">
        <button
          onClick={() => { acoes.registrarContato(n.id); toast(`Contato com ${primeiroNome(c?.nome || "")} registrado. O prazo reiniciou.`, "ok"); }}
          className="flex items-center gap-1.5 rounded-lg bg-white px-3 py-2 text-xs font-medium text-slate-700 ring-1 ring-slate-200 transition hover:bg-slate-100"
        >
          <Check size={14} /> Falei com ele
        </button>
        <Adiar onAdiar={(d) => acoes.adiar(n.id, d)} />
        <button onClick={() => acoes.marcarPerdido(n)} className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium text-slate-400 transition hover:bg-rose-50 hover:text-rose-600">
          <ThumbsDown size={14} /> Perdi este
        </button>
        <div className="ml-auto flex items-center gap-3">
          {!podeAvancar && r.proxima && (
            <span className="text-xs text-slate-400">
              {travadoPelaRegra ? `Faltam: ${camposFaltando(n).join(", ")}` : `Faltam ${pendentes.length} ${pendentes.length === 1 ? "passo" : "passos"}`}
            </span>
          )}
          {r.proxima && (
            <button disabled={!podeAvancar} onClick={() => acoes.concluirEtapa(n)} className="flex items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:bg-slate-300">
              Avançar para {r.proxima} <ArrowRight size={15} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/* ===================== CARD 2 — COBRANÇA ===================== */

function CardCobranca({ item, acoes, toast }) {
  const n = item.negocio;
  const c = item.cliente;
  const vencidas = parcelasVencidas(n);
  const critico = item.camada === CAMADAS.ENTREGA_CRITICA;
  const msg = `Olá ${primeiroNome(c?.nome || "")}, tudo bem? Passando para lembrar da parcela da sua viagem para ${n.destino}, que consta em aberto por aqui. Se já tiver pago, me manda o comprovante que eu dou baixa. Qualquer coisa, a gente conversa sobre a melhor forma.`;

  return (
    <div className="overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
      <Faixa tom={critico ? "rose" : "amber"} icone={BadgeDollarSign} texto={item.motivo} />
      <div className="p-6">
        <Topo c={c} n={n} acoes={acoes} rotulo="Cobrança" />

        <div className="mt-4 grid grid-cols-3 gap-3 rounded-xl bg-slate-50 p-4">
          <Dado icone={Wallet} rotulo="Venda" valor={fmtMoeda(n.valor_venda)} />
          <Dado icone={TrendingUp} rotulo="Em aberto" valor={fmtMoeda(saldoAberto(n))} />
          <Dado icone={Calendar} rotulo="Vencido" valor={fmtMoeda(valorVencido(n))} faltando={valorVencido(n) > 0} />
        </div>

        {critico && (
          <div className="mt-4 flex items-start gap-2 rounded-lg bg-rose-50 p-3 text-xs leading-relaxed text-rose-800 ring-1 ring-rose-200">
            <Lock size={14} className="mt-0.5 flex-shrink-0" />
            <span>
              <strong>Bilhete travado.</strong> Pagamento {statusPagamento(n).toLowerCase()} e embarque em {diasAte(n.data_ida)} dias. Esta trava é automática: ela lê as parcelas, não depende de você lembrar de nada.
            </span>
          </div>
        )}

        <div className="mt-5">
          <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">Parcelas</p>
          <div className="space-y-1">
            {(n.parcelas || []).map((p) => (
              <Parcela key={p.id || p.n} p={p} onToggle={() => acoes.togglePagoParcela(n.id, p.n)} />
            ))}
          </div>
        </div>

        <Script texto={msg} whats={c?.whatsapp} onEnviar={() => acoes.registrarContato(n.id)} toast={toast} rotulo="Cobrança sem constrangimento" />
      </div>

      <div className="flex flex-wrap items-center gap-2 border-t border-slate-200 bg-slate-50 px-6 py-4">
        <button
          onClick={() => { vencidas.forEach((p) => acoes.togglePagoParcela(n.id, p.n)); toast("Baixa registrada. A trava do bilhete recalcula sozinha.", "ok"); }}
          disabled={!vencidas.length}
          className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 text-xs font-medium text-white transition hover:bg-emerald-700 disabled:bg-slate-300"
        >
          <Check size={14} /> Dar baixa no que venceu
        </button>
        <Adiar onAdiar={(d) => acoes.adiar(n.id, d)} />
      </div>
    </div>
  );
}

/* ===================== CARD 3 — VIAGEM ===================== */

function CardViagem({ item, acoes, toast }) {
  const n = item.negocio;
  const c = item.cliente;
  const m = item.marco;
  const trava = m.trava ? m.trava(n) : null;
  const travado = Array.isArray(trava) && trava.length > 0;
  const msg = m.mensagem ? m.mensagem(n, c) : null;
  const prog = progressoJornada(n);

  return (
    <div className="overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
      <Faixa tom={item.camada === CAMADAS.ENTREGA_CRITICA ? "violet" : "blue"} icone={Plane} texto={item.motivo} />
      <div className="p-6">
        <Topo c={c} n={n} acoes={acoes} rotulo={item.fase} corRotulo={COR_FASE[item.fase]} />

        <div className="mt-4 grid grid-cols-3 gap-3 rounded-xl bg-slate-50 p-4">
          <Dado icone={MapPin} rotulo="Destino" valor={n.destino} />
          <Dado icone={Calendar} rotulo="Ida" valor={fmtData(n.data_ida)} />
          <Dado icone={Calendar} rotulo="Volta" valor={fmtData(n.data_volta)} />
        </div>

        <div className="mt-6 rounded-xl border border-slate-200 p-4">
          <div className="mb-1 flex items-center justify-between">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">Próximo cuidado</p>
            <span className="text-xs text-slate-400">{prog.feitos} de {prog.total}</span>
          </div>
          <p className="text-sm font-semibold text-slate-900">{m.titulo}</p>
          <p className="mt-1 text-sm leading-relaxed text-slate-500">{m.porque}</p>

          {travado && (
            <div className="mt-3 rounded-lg bg-rose-50 p-3 ring-1 ring-rose-200">
              <p className="flex items-center gap-1.5 text-xs font-semibold text-rose-800">
                <Lock size={12} /> Travado — não faça isso ainda
              </p>
              <ul className="mt-1.5 space-y-1">
                {trava.map((t, i) => (
                  <li key={i} className="text-xs leading-relaxed text-rose-700">• {t}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        {msg && !travado && <Script texto={msg} whats={c?.whatsapp} onEnviar={() => acoes.registrarContato(n.id)} toast={toast} />}
        {m.interno && <p className="mt-3 text-xs italic text-slate-400">Tarefa interna: não há mensagem para o cliente aqui.</p>}
      </div>

      <div className="flex flex-wrap items-center gap-2 border-t border-slate-200 bg-slate-50 px-6 py-4">
        <button
          disabled={travado}
          onClick={() => { acoes.marcarMarco(n.id, m.id, true); toast(`"${m.titulo}" concluído.`, "ok"); }}
          className="flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-2 text-xs font-medium text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:bg-slate-300"
        >
          <Check size={14} /> {travado ? "Resolva a trava primeiro" : "Marcar como feito"}
        </button>
        <Adiar onAdiar={(d) => acoes.adiar(n.id, d)} />
      </div>
    </div>
  );
}

/* ===================== CARD 4 — PROSPECÇÃO ===================== */

function CardProspeccao({ item, acoes, toast }) {
  const c = item.cliente;
  const g = item.gatilho;

  return (
    <div className="overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
      <Faixa tom="emerald" icone={Gift} texto={item.motivo} />
      <div className="p-6">
        <div>
          <span className="text-xs font-medium uppercase tracking-wide text-emerald-600">Prospecção</span>
          <h1 className="mt-1 text-2xl font-semibold text-slate-900">{c?.nome}</h1>
          <p className="mt-0.5 text-sm text-slate-500">{c?.whatsapp} · veio do {c?.origem}</p>
        </div>

        <div className="mt-5 rounded-xl bg-emerald-50 p-4 ring-1 ring-emerald-100">
          <p className="text-sm font-semibold text-emerald-900">{g.titulo}</p>
          <p className="mt-1 text-sm leading-relaxed text-emerald-800">{g.porque}</p>
        </div>

        <Script texto={item.mensagem} whats={c?.whatsapp} toast={toast} rotulo="Mensagem sem venda dentro" />
      </div>

      <div className="flex flex-wrap items-center gap-2 border-t border-slate-200 bg-slate-50 px-6 py-4">
        <button
          onClick={() => { acoes.prospeccaoFeita(c.id, g.id); toast("Feito. Este gatilho não volta para esse cliente.", "ok"); }}
          className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 text-xs font-medium text-white transition hover:bg-emerald-700"
        >
          <Check size={14} /> Falei com ele
        </button>
        <button
          onClick={() => { acoes.prospeccaoFeita(c.id, g.id); toast("Dispensado.", "ok"); }}
          className="rounded-lg px-3 py-2 text-xs font-medium text-slate-400 transition hover:bg-slate-100"
        >
          Agora não
        </button>
      </div>
    </div>
  );
}

/* ===================== Auxiliares ===================== */

const TONS = {
  blue: "bg-blue-50 text-blue-800",
  amber: "bg-amber-50 text-amber-800",
  rose: "bg-rose-50 text-rose-800",
  violet: "bg-violet-50 text-violet-800",
  emerald: "bg-emerald-50 text-emerald-800",
};

function Faixa({ tom, icone: Icone, texto }) {
  return (
    <div className={`flex items-center gap-2 px-6 py-3 text-sm ${TONS[tom]}`}>
      <Icone size={15} className="flex-shrink-0" />
      <span className="font-medium">{texto}</span>
    </div>
  );
}

function Topo({ c, n, acoes, rotulo, corRotulo }) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-3">
      <div>
        <div className="flex items-center gap-2">
          <span className={`h-2.5 w-2.5 rounded-full ${corRotulo || PONTO_ETAPA[n.etapa_funil]}`} />
          <span className="text-xs font-medium uppercase tracking-wide text-slate-500">{rotulo || n.etapa_funil}</span>
          <span className="text-xs text-slate-400">· falou {rotuloTempo(n.ultima_interacao)}</span>
        </div>
        <h1 className="mt-1 text-2xl font-semibold text-slate-900">{c?.nome}</h1>
        <p className="mt-0.5 text-sm text-slate-500">
          {c?.whatsapp} · veio do {c?.origem}{n.motivo_viagem ? ` · ${n.motivo_viagem}` : ""}
        </p>
      </div>
      <button onClick={() => acoes.abrirEdicao(n)} className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium text-slate-500 ring-1 ring-slate-200 transition hover:bg-slate-50">
        <Pencil size={13} /> Editar dados
      </button>
    </div>
  );
}

function Script({ texto, whats, onEnviar, toast, rotulo }) {
  if (!texto) return null;
  return (
    <div className="mt-5 rounded-xl border border-slate-200 p-4">
      <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-slate-400">{rotulo || "O que dizer agora"}</p>
      <p className="text-sm leading-relaxed text-slate-700">{texto}</p>
      <div className="mt-3 flex flex-wrap gap-2">
        <a href={linkWhats(whats, texto)} target="_blank" rel="noreferrer" onClick={onEnviar} className="flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-2 text-xs font-medium text-white transition hover:bg-emerald-700">
          <MessageCircle size={14} /> Abrir no WhatsApp
        </a>
        <button onClick={() => { navigator.clipboard?.writeText(texto); toast("Mensagem copiada.", "ok"); }} className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-xs font-medium text-slate-600 ring-1 ring-slate-200 transition hover:bg-slate-50">
          <Copy size={14} /> Copiar
        </button>
      </div>
    </div>
  );
}

function Parcela({ p, onToggle }) {
  const hoje = new Date().toISOString().slice(0, 10);
  const vencida = !p.pago && p.vencimento < hoje;
  return (
    <button onClick={onToggle} className="flex w-full items-center gap-3 rounded-lg px-2 py-2 text-left transition hover:bg-slate-50">
      {p.pago ? <CheckCircle2 size={16} className="flex-shrink-0 text-emerald-500" /> : <Circle size={16} className={`flex-shrink-0 ${vencida ? "text-rose-400" : "text-slate-300"}`} />}
      <span className={`flex-1 text-sm ${p.pago ? "text-slate-400 line-through" : "text-slate-700"}`}>Parcela {p.n}</span>
      <span className={`text-xs ${vencida ? "font-medium text-rose-600" : "text-slate-400"}`}>
        {vencida ? "venceu " : "vence "}{fmtData(p.vencimento)}
      </span>
      <span className="w-24 text-right text-sm font-semibold text-slate-800">{fmtMoeda(p.valor)}</span>
    </button>
  );
}

function ItemFila({ item, onClick }) {
  const c = item.cliente;
  const n = item.negocio;
  const Icone = item.tipo === "viagem" ? Plane : item.tipo === "prospeccao" ? Gift : item.tipo === "cobranca" ? BadgeDollarSign : null;

  return (
    <button onClick={onClick} className="flex w-full items-center gap-3 rounded-xl bg-white px-4 py-3 text-left shadow-sm ring-1 ring-slate-200 transition hover:ring-blue-300">
      {Icone ? <Icone size={14} className="flex-shrink-0 text-slate-400" /> : <span className={`h-2 w-2 flex-shrink-0 rounded-full ${PONTO_ETAPA[n?.etapa_funil]}`} />}
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <p className="truncate text-sm font-medium text-slate-800">{c?.nome}</p>
          {item.tipo === "venda" && <Termo negocio={n} />}
        </div>
        <p className="truncate text-xs text-slate-500">{item.motivo}</p>
      </div>
      <span className="flex-shrink-0 rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-medium text-slate-500">{ROTULO_CAMADA[item.camada]}</span>
      <ChevronRight size={16} className="flex-shrink-0 text-slate-300" />
    </button>
  );
}

function Termo({ negocio }) {
  const t = temperatura(negocio);
  const c = COR_TEMPERATURA[t.faixa];
  return <span className={`flex-shrink-0 rounded px-1.5 py-0.5 text-[10px] font-semibold ${c.fundo} ${c.texto}`}>{t.faixa} {t.nota}</span>;
}

function Metrica({ valor, rotulo, alerta }) {
  return (
    <div>
      <p className={`text-lg font-semibold ${alerta ? "text-amber-600" : "text-slate-800"}`}>{valor}</p>
      <p className="text-xs text-slate-400">{rotulo}</p>
    </div>
  );
}

function Caixa({ rotulo, valor, sub, alerta }) {
  return (
    <div className={`rounded-xl p-3 ring-1 ${alerta ? "bg-rose-50 ring-rose-200" : "bg-white ring-slate-200"}`}>
      <p className={`text-xs ${alerta ? "text-rose-600" : "text-slate-400"}`}>{rotulo}</p>
      <p className={`mt-0.5 text-base font-bold ${alerta ? "text-rose-700" : "text-slate-800"}`}>{valor}</p>
      {sub && <p className="text-xs text-slate-400">{sub}</p>}
    </div>
  );
}

function Dado({ icone: Icone, rotulo, valor, extra, faltando }) {
  return (
    <div>
      <p className="flex items-center gap-1 text-xs text-slate-400"><Icone size={12} /> {rotulo}</p>
      <p className={`mt-0.5 truncate text-sm font-medium ${faltando ? "text-rose-500" : "text-slate-800"}`}>
        {valor}{extra && <span className="ml-1 text-xs font-normal text-slate-400">{extra}</span>}
      </p>
    </div>
  );
}

function Adiar({ onAdiar }) {
  const [aberto, setAberto] = useState(false);
  return (
    <div className="relative">
      <button onClick={() => setAberto((a) => !a)} className="flex items-center gap-1.5 rounded-lg bg-white px-3 py-2 text-xs font-medium text-slate-700 ring-1 ring-slate-200 transition hover:bg-slate-100">
        <Clock size={14} /> Adiar
      </button>
      {aberto && (
        <div className="absolute bottom-full left-0 z-10 mb-2 w-40 overflow-hidden rounded-lg bg-white py-1 shadow-lg ring-1 ring-slate-200">
          {[{ d: 1, t: "Amanhã" }, { d: 3, t: "Em 3 dias" }, { d: 7, t: "Na semana que vem" }, { d: 30, t: "Em 1 mês" }].map((o) => (
            <button key={o.d} onClick={() => { onAdiar(o.d); setAberto(false); }} className="block w-full px-3 py-2 text-left text-xs text-slate-600 hover:bg-slate-50">
              {o.t}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function Objecoes({ negocio, toast }) {
  const [aberta, setAberta] = useState(null);
  return (
    <div className="mt-5 rounded-xl border border-amber-200 bg-amber-50 p-4">
      <p className="mb-1 text-xs font-semibold uppercase tracking-wider text-amber-700">O que ele te disse?</p>
      <p className="mb-3 text-xs text-amber-800">Clique na objeção para ver a leitura e a resposta.</p>
      <div className="flex flex-wrap gap-2">
        {OBJECOES.map((o) => (
          <button key={o.id} onClick={() => setAberta(aberta === o.id ? null : o.id)} className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${aberta === o.id ? "bg-amber-600 text-white" : "bg-white text-amber-800 ring-1 ring-amber-200 hover:bg-amber-100"}`}>
            {o.titulo}
          </button>
        ))}
      </div>
      {aberta && (
        <div className="mt-3 rounded-lg bg-white p-3 ring-1 ring-amber-200">
          {(() => {
            const o = OBJECOES.find((x) => x.id === aberta);
            const texto = o.resposta(negocio);
            return (
              <>
                <p className="text-xs font-medium text-amber-700">{o.leitura}</p>
                <p className="mt-2 text-sm leading-relaxed text-slate-700">{texto}</p>
                <button onClick={() => { navigator.clipboard?.writeText(texto); toast("Resposta copiada.", "ok"); }} className="mt-2 flex items-center gap-1 text-xs font-medium text-blue-600 hover:text-blue-800">
                  <Copy size={12} /> Copiar resposta
                </button>
              </>
            );
          })()}
        </div>
      )}
    </div>
  );
}
